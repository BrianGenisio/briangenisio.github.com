﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwitterMVVM.Model
{
    public class Tweet
    {
        public string Text { get; set; }
        public string AuthorName { get; set; }
        public string AuthorImageURI { get; set; }
    }
}
