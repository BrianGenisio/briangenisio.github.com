using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using TwitterMVVM.Model;

namespace TwitterMVVM
{
    public interface ITwitterModel
    {
        void Search(string searchText, Action<IEnumerable<Tweet>> whenComplete);
    }

    public class TwitterModel : ITwitterModel
    {
        public void Search(string searchText, Action<IEnumerable<Tweet>> whenComplete)
        {
            var downloader = new WebClient();
            downloader.OpenReadCompleted += (sender, e) => SearchResultsComplete(e.Result, whenComplete);
            downloader.OpenReadAsync(new Uri("http://search.twitter.com/search.atom?q=" + searchText));
        }

        private void SearchResultsComplete(Stream data, Action<IEnumerable<Tweet>> whenComplete)
        {
            using (var reader = new StreamReader(data))
            {
                var xmlResult = reader.ReadToEnd();
                var document = XDocument.Parse(xmlResult);

                XNamespace ATOM = "http://www.w3.org/2005/Atom";

                var results =
                    from entry in document.Descendants(ATOM + "entry")
                    select new Tweet
                               {
                                   Text = entry.Element(ATOM + "title").Value,
                                   AuthorName = entry.Element(ATOM + "author").Element(ATOM + "name").Value,
                                   AuthorImageURI = (from link in entry.Elements(ATOM + "link")
                                                     where link.Attribute("rel").Value == "image"
                                                     select link.Attribute("href").Value).FirstOrDefault()
                               };

                whenComplete(results);
            }
        }
    }
}