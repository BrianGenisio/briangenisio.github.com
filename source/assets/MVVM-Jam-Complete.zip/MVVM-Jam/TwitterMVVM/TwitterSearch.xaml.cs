﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using TwitterMVVM.Model;

namespace TwitterMVVM
{
    /// <summary>
    /// Interaction logic for TwitterSearch.xaml
    /// </summary>
    public partial class TwitterSearch : Window
    {
        public TwitterSearch()
        {
            InitializeComponent();
        }
    }
}