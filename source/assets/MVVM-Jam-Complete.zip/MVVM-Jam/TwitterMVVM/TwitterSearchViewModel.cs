﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using TwitterMVVM.Model;
using TwitterMVVM.MVVM;

namespace TwitterMVVM
{
    public class TwitterSearchViewModel : INotifyPropertyChanged
    {
        private readonly ITwitterModel model;

        public TwitterSearchViewModel() : this(new TwitterModel())
        {
        }

        public TwitterSearchViewModel(ITwitterModel model)
        {
            if(model == null)
                throw new ArgumentNullException("model");

            this.model = model;
            SearchCommand = new DelegateCommand<object>(ExecuteSearch, CanExecuteSearch);
            Tweets = new ObservableCollection<TweetViewModel>();
        }

        private bool CanExecuteSearch(object obj)
        {
            return !string.IsNullOrEmpty(SearchText);
        }

        private void ExecuteSearch(object parameter)
        {
            SearchStatus = "Searching Twitter...";
            Tweets.Clear();
            model.Search(SearchText, SearchComplete);
        }

        private void SearchComplete(IEnumerable<Tweet> tweets)
        {
            SearchStatus = string.Empty;

            foreach (var tweet in tweets)
            {
                Tweets.Add(new TweetViewModel(tweet));
            }
        }

        protected void OnPropertyChanged(string propertyName)
        {
            if(PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        private string searchText;
        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                SearchCommand.NotifyCanExecuteChanged();
            }
        }

        public DelegateCommand<object> SearchCommand { get; set; }

        public ObservableCollection<TweetViewModel> Tweets { get; private set; }
        
        private string searchStatus;

        public string SearchStatus
        {
            get { return searchStatus; }
            set
            {
                searchStatus = value;
                OnPropertyChanged("SearchStatus");
            }
        }
    
        public event PropertyChangedEventHandler PropertyChanged;

    }
}
