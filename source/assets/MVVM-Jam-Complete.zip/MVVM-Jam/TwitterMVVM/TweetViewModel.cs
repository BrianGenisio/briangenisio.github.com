using System;
using System.Windows;
using TwitterMVVM.Model;

namespace TwitterMVVM
{
    public class TweetViewModel
    {
        private readonly Tweet tweet;

        public TweetViewModel(Tweet tweet)
        {
            this.tweet = tweet;
        }

        public string AuthorImageURI { get { return tweet.AuthorImageURI; } }
        public string Text { get { return tweet.Text; } }
        public string AuthorName { get { return tweet.AuthorName.Split("(".ToCharArray())[0].Trim(); } }
        public Visibility ShowImageNotFound { get { return string.IsNullOrEmpty(AuthorImageURI) ? Visibility.Visible : Visibility.Collapsed; } }
        
    }
}