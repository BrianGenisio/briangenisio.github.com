using System;
using System.Windows.Input;

namespace TwitterMVVM.MVVM
{
    public class DelegateCommand<T> : ICommand
    {
        private readonly Action<T> _action;
        private readonly Predicate<T> _canExecute;

        public DelegateCommand(Action<T> action, Predicate<T> canExecute)
        {
            if(action == null) throw new ArgumentNullException("action");
            if(canExecute == null) throw new ArgumentNullException("canExecute");

            _action = action;
            _canExecute = canExecute;
        }

        public DelegateCommand(Action<T> action) : this(action, x => true)
        {
        }

        public void Execute(object parameter)
        {
            _action((T)parameter);
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute((T) parameter);
        }

        public void NotifyCanExecuteChanged()
        {
            var handlers = CanExecuteChanged;
            if (handlers != null)
                handlers(this, EventArgs.Empty);
        }

        public event EventHandler CanExecuteChanged;
    }
}
