using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using System;
using TwitterMVVM;
using TwitterMVVM.Model;

namespace TwitterMVVMTests.ViewModels
{
    [TestFixture]
    public class TwitterSearchViewModelTests
    {
        private Mock<ITwitterModel> _mockModel;
        private TwitterSearchViewModel _viewModel;

        [SetUp]
        public virtual void SetUp()
        {
            _mockModel = new Mock<ITwitterModel>();
            _viewModel = new TwitterSearchViewModel(_mockModel.Object);
        }

        [Test]
        public void Executing_Search_Requests_Data()
        {
            _viewModel.SearchText = "Beets";

            _viewModel.SearchCommand.Execute(null);

            _mockModel.Verify(model => model.Search(
                "Beets", It.IsAny<Action<IEnumerable<Tweet>>>()));
        }

        [Test]
        public void Executing_Search_Sets_Status_Message()
        {
            string propertyName = string.Empty;
            _viewModel.PropertyChanged += (s, e) => propertyName = e.PropertyName;

            _viewModel.SearchCommand.Execute(null);

            Assert.That(propertyName, Is.EqualTo("SearchStatus"));
            Assert.That(_viewModel.SearchStatus.Contains("Searching"));
        }

        private void SetupModelResults(string query, params Tweet[] tweets)
        {
            _mockModel.Setup(model =>
                model.Search(query, It.IsAny<Action<IEnumerable<Tweet>>>()))
                .Callback((string q, Action<IEnumerable<Tweet>> callback) =>
                    callback(tweets));
        }

        [Test]
        public void Search_Complete_Sets_Tweets()
        {
            SetupModelResults("Zune", new Tweet {Text = "Sweet"}, new Tweet{Text = "Sour"});
            _viewModel.SearchText = "Zune";

            _viewModel.SearchCommand.Execute(null);

            Assert.That(_viewModel.Tweets.Count, Is.EqualTo(2));
            Assert.That(_viewModel.Tweets[0].Text, Is.EqualTo("Sweet"));
            Assert.That(_viewModel.Tweets[1].Text, Is.EqualTo("Sour"));
        }

        [Test]
        public void Search_Complete_Clears_Status_Message()
        {
            SetupModelResults("iPhone");
            _viewModel.SearchText = "iPhone";

            _viewModel.SearchCommand.Execute(null);

            Assert.That(_viewModel.SearchStatus, Is.EqualTo(string.Empty));
        }

        [Test]
        public void Executing_Search_Clears_Existing_Tweets()
        {
            _viewModel.Tweets.Add(new TweetViewModel(new Tweet()));
            _viewModel.SearchText = "Macaroni Salad";

            _viewModel.SearchCommand.Execute(null);

            Assert.That(_viewModel.Tweets.Count, Is.EqualTo(0));
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Null_Model_Throws_Exception()
        {
            _viewModel = new TwitterSearchViewModel(null);
        }

        [Test]
        public void Search_Command_Is_Not_Executable_When_Text_Is_Empty()
        {
            _viewModel.SearchText = string.Empty;

            Assert.That(_viewModel.SearchCommand.CanExecute(null), Is.False);
        }

        [Test]
        public void Search_Command_Is_Executable_When_Text_Has_Value()
        {
            _viewModel.SearchText = "Data";

            Assert.That(_viewModel.SearchCommand.CanExecute(null));
        }

        [Test]
        public void Setting_Search_Text_Fires_CanExecuteChanged()
        {
            bool eventWasFired = false;
            _viewModel.SearchCommand.CanExecuteChanged += (s, e) => eventWasFired = true;

            _viewModel.SearchText = "foo";

            Assert.That(eventWasFired);
        }
    }
}