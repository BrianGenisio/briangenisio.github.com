using NUnit.Framework;
using System.Windows;
using TwitterMVVM;
using TwitterMVVM.Model;

namespace TwitterMVVMTests.ViewModels
{
    [TestFixture]
    public class TweetViewModelTests
    {

        private TweetViewModel ViewModel(string author, string uri, string text)
        {
            return new TweetViewModel(
                new Tweet
                {
                    AuthorName = author,
                    AuthorImageURI = uri,
                    Text = text
                });
        }

        [Test]
        public void Verify_Pass_Thru_Properties()
        {
            var viewModel = ViewModel("", "foo", "bar");

            Assert.That(viewModel.AuthorImageURI, Is.EqualTo("foo"));
            Assert.That(viewModel.Text, Is.EqualTo("bar"));
        }

        [Test]
        public void UserName_Is_Extracted()
        {
            var viewModel = ViewModel("UserName (Real Name)", "", "");

            Assert.That(viewModel.AuthorName, Is.EqualTo("UserName"));
        }

        [Test]
        public void URI_Is_Empty_So_Display_NotFound()
        {
            var viewModel = ViewModel("", "", "");

            Assert.That(viewModel.ShowImageNotFound, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void URI_With_Value_Hide_NotFound()
        {
            var viewModel = ViewModel("", "foo", "");

            Assert.That(viewModel.ShowImageNotFound, Is.EqualTo(Visibility.Collapsed));
        }
    }
}