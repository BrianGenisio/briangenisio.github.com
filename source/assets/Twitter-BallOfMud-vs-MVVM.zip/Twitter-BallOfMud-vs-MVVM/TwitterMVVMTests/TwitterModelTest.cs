using System.Collections.Generic;
using System.Linq;
using Moq;
using NUnit.Framework;
using TwitterMVVM.MVVM.Model;
using TwitterMVVM.MVVM.Services;
using System;
using System.Reflection;
using System.IO;

namespace TwitterMVVMTests
{
    [TestFixture]
    public class TwitterModelTest
    {
        private Mock<ITwitterService> _mockService;
        private TwitterModel _model;

        [SetUp]
        public virtual void SetUp()
        {
            _mockService = new Mock<ITwitterService>();
            _model = new TwitterModel(_mockService.Object);
        }

        private static string GetCapturedXML()
        {
            using (var stream = Assembly.GetCallingAssembly().GetManifestResourceStream("TwitterMVVMTests.ServiceData.xml"))
            using (var reader = new StreamReader(stream))
                return reader.ReadToEnd();
        }

        [Test, ExpectedException(typeof(ArgumentNullException))]
        public void Null_Service_Throws_Exception()
        {
            _model = new TwitterModel(null);
        }

        [Test]
        public void Model_Results_Parses_Properly()
        {
            List<Tweet> results = null;
            _model.SearchTwitter("MacaroniSalad", tweets => results = tweets.ToList());

            _mockService.Raise(service => service.SearchTwitterComplete += null, new SearchTwitterEventArgs(GetCapturedXML()));

            Assert.That(results.Count, Is.EqualTo(2));

            Assert.That(results[0].AuthorImageURI, Is.EqualTo("Matt-small_normal.jpeg"));
            Assert.That(results[0].AuthorName, Is.EqualTo("MMiddleton (Matt Middleton)"));
            Assert.That(results[0].Text, Is.EqualTo("I like food"));

            Assert.That(results[1].AuthorImageURI, Is.EqualTo("iphoner_normal.jpg"));
            Assert.That(results[1].AuthorName, Is.EqualTo("BkReemo (Kareem A.)"));
            Assert.That(results[1].Text, Is.EqualTo("Me too"));
        }
    }
}