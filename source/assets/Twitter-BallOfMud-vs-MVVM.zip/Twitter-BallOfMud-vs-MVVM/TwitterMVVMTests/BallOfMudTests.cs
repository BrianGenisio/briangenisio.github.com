using NUnit.Framework;
using TwitterMVVM.BallOfMud;

namespace TwitterMVVMTests
{
    [TestFixture]
    public class BallOfMudTests
    {

        [Test]
        public void Search_Button_Is_Disabled_By_Default()
        {
        }
    }
}