﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Windows;
using System.Xml.Linq;
using System.Windows.Data;

namespace TwitterMVVM.BallOfMud
{
    /// <summary>
    /// Interaction logic for TwitterSearch.xaml
    /// </summary>
    public partial class TwitterSearch : Window
    {
        public TwitterSearch()
        {
            InitializeComponent();
        }

        private void SearchButtonClicked(object sender, RoutedEventArgs e)
        {
            SearchStatus.Text = "Searching Twitter...";

            var downloader = new WebClient();
            downloader.OpenReadCompleted += SearchResultsComplete;
            downloader.OpenReadAsync(new Uri("http://search.twitter.com/search.atom?q=" + SearchText.Text));
        }

        private void SearchResultsComplete(object sender, OpenReadCompletedEventArgs e)
        {
            SearchStatus.Text = string.Empty;

            using(var reader = new StreamReader(e.Result))
            {
                var xmlResult = reader.ReadToEnd();
                var document = XDocument.Parse(xmlResult);

                XNamespace ATOM = "http://www.w3.org/2005/Atom";

                SearchResults.ItemsSource =
                    from entry in document.Descendants(ATOM + "entry")
                    select new
                           {
                               Text = entry.Element(ATOM + "title").Value,
                               AuthorName = entry.Element(ATOM + "author").Element(ATOM + "name").Value.Split("(".ToCharArray())[0],
                               AuthorImageURI = (from link in entry.Elements(ATOM + "link")
                                                 where link.Attribute("rel").Value == "image"
                                                 select link.Attribute("href").Value).FirstOrDefault()
                           };
                
            }
        }

        private void SearchTextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            SearchButton.IsEnabled = SearchText.Text.Length > 0;
        }
    }

    public class ImageNotFoundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return string.IsNullOrEmpty(value as string)
                       ? Visibility.Visible
                       : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}