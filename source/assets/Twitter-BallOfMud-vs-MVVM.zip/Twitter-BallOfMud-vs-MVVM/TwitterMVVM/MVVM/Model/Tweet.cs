﻿namespace TwitterMVVM.MVVM.Model
{
    public struct Tweet
    {
        public string Text { get; set; }
        public string AuthorName { get; set; }
        public string AuthorImageURI { get; set; }
    }
}