using System;
using System.Collections.Generic;

namespace TwitterMVVM.MVVM.Model
{
    public interface ITwitterModel
    {
        void SearchTwitter(string searchText, Action<IEnumerable<Tweet>> searchCompleted);        
    }
}