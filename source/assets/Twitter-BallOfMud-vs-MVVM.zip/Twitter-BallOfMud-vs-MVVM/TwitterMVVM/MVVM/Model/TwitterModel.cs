﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using TwitterMVVM.MVVM.Services;

namespace TwitterMVVM.MVVM.Model
{
    public class TwitterModel : ITwitterModel
    {
        private readonly ITwitterService _service;

        public TwitterModel(ITwitterService service)
        {
            if (service == null) throw new ArgumentNullException("service");

            _service = service;
        }

        public TwitterModel()
            : this(new TwitterService())
        { }

        private Action<IEnumerable<Tweet>> _searchComplete;

        public void SearchTwitter(string searchText, Action<IEnumerable<Tweet>> searchCompleted)
        {
            _searchComplete = searchCompleted;

            _service.SearchTwitterComplete += SearchResultsComplete;
            _service.SearchTwitterAsync(searchText, SearchTwitterFormat.XML);
        }

        private void SearchResultsComplete(object sender, SearchTwitterEventArgs e)
        {
            var document = XDocument.Parse(e.Results);

            XNamespace ATOM = "http://www.w3.org/2005/Atom";

            var tweets =
                from entry in document.Descendants(ATOM + "entry")
                select new Tweet
                       {
                           Text = entry.Element(ATOM + "title").Value,
                           AuthorName = entry.Element(ATOM + "author").Element(ATOM + "name").Value,
                           AuthorImageURI = (from link in entry.Elements(ATOM + "link")
                                             where link.Attribute("rel").Value == "image"
                                             select link.Attribute("href").Value).FirstOrDefault()
                       };

            _searchComplete(tweets);
        }
    }
}
