﻿using System;
using System.Collections.Generic;

namespace TwitterMVVM.MVVM.Model
{
    class CannedDataModel : ITwitterModel
    {
        private static readonly Tweet[] CannedData = new [] {
            new Tweet { AuthorImageURI = "", AuthorName = "Poeticjustis73 (Nikki Bee)", Text = "@kirstiealley I just made a yummy summer meal, bbq hamburgers, homemade macaroni & potato salad, watermelon and strawyberry shortcake! mmm" },
            new Tweet { AuthorImageURI = "", AuthorName = "Rydyr (Rydyr R)", Text = "making macaroni salad, pondering coffee, listening to fantastic music, and working on some chemistry...how's that for multitasking universe" },
            new Tweet { AuthorImageURI = "", AuthorName = "LottieMac (Charlotte Macabulos)", Text = "cofee....potato salad and macaroni  and cheese.. what a breakfast combination...." },
            new Tweet { AuthorImageURI = "", AuthorName = "GABBYiSACTiVE (Gabby)", Text = "@iamvictorious ~ I had Chicken Katsu w/ rice & macaroni salad." },
            new Tweet { AuthorImageURI = "", AuthorName = "radioxoxo (Radioxoxo)", Text = "This hot macaroni makes a  good salad side dish each time I add miracle whip some chopped onions http://radioxoxo.ning.com" },
            new Tweet { AuthorImageURI = "", AuthorName = "CityUndead (City Undead)", Text = "This macaroni salad is awful... Listening to Murderdolls." },
            new Tweet { AuthorImageURI = "", AuthorName = "EmilyyEmu (Emily Hess)", Text = "EATING GOAT MEAT... just kidding, eating macaroni salad." },
            new Tweet { AuthorImageURI = "", AuthorName = "HisMor3na (LaVitt Wright)", Text = "eating sum bombass macaroni salad that mario's aunt made... its so good, i luv when she makes this stuff!!!" },
            new Tweet { AuthorImageURI = "", AuthorName = "ummzahra (Victoria Herrera)", Text = "is stuffed: steak, macaroni salad, and cookies - NO VEGGIES? argh!" },
            new Tweet { AuthorImageURI = "", AuthorName = "blaqrainbow (tink lez)", Text = "smh...i made this fire ass macaroni salad for the cook out yesterday an forgot to put the pickles in...thot i was missin sumthin" },
            new Tweet { AuthorImageURI = "", AuthorName = "blaqrainbow (tink lez)", Text = "smh...i made this fire ass macaroni salad for the cook out yesterday an forgot to put the pickles in...tholt i was missin sumthin" },
            new Tweet { AuthorImageURI = "", AuthorName = "jenncharina (Jenn)", Text = "- Fried chicken, gravy, macaroni salad and banoffee pie #fb" },
            new Tweet { AuthorImageURI = "", AuthorName = "FashionLIFE (Marcus Bailey)", Text = "@darErule lawd lol my moms made baked macaroni and cheese! and seafood salad." },
            new Tweet { AuthorImageURI = "", AuthorName = "karla2556 (Karla M)", Text = "Summer feast: BBQ chicken, macaroni salad & corn on the cob..strawberry shortcake for dessert!" },
            new Tweet { AuthorImageURI = "", AuthorName = "blackgirlchi (Kiratiana)", Text = "@germasonHJ I can cook my behind off! You know greens, cornbread, fried chicken, macaroni and cheese and potato salad? Sweet potato pie?" }
        };

        public void SearchTwitter(string searchText, Action<IEnumerable<Tweet>> searchCompleted)
        {
            searchCompleted(CannedData);
        }
    }
}
