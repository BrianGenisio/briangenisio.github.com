﻿using System;
using System.IO;
using System.Net;

namespace TwitterMVVM.MVVM.Services
{
    public class TwitterService : ITwitterService
    {
        public void SearchTwitterAsync(string query, SearchTwitterFormat format)
        {
            var downloader = new WebClient();
            downloader.OpenReadCompleted += SearchResultsComplete;

            string searchType = format == SearchTwitterFormat.XML ? "atom" : "json";
            string twitterURL = string.Format("http://search.twitter.com/search.{0}?q={1}", searchType, query);

            downloader.OpenReadAsync(new Uri(twitterURL));
        
        }

        private void SearchResultsComplete(object sender, OpenReadCompletedEventArgs e)
        {
            string result;

            using (var reader = new StreamReader(e.Result))
                result = reader.ReadToEnd();

            var handlers = SearchTwitterComplete;
            if(handlers != null)
                handlers(this, new SearchTwitterEventArgs(result));
        }

        public event EventHandler<SearchTwitterEventArgs> SearchTwitterComplete;
    }
}
