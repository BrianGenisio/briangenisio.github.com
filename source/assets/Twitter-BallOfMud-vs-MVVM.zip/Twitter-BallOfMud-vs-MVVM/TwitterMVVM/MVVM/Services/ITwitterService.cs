using System;

namespace TwitterMVVM.MVVM.Services
{
    public interface ITwitterService
    {
        void SearchTwitterAsync(string query, SearchTwitterFormat format);
        event EventHandler<SearchTwitterEventArgs> SearchTwitterComplete;
    }

    public enum SearchTwitterFormat
    {
        XML,
        JSON
    }

    public class SearchTwitterEventArgs : EventArgs
    {
        public SearchTwitterEventArgs(string result)
        {
            Results = result;
        }

        public string Results { get; private set; }
    }
}