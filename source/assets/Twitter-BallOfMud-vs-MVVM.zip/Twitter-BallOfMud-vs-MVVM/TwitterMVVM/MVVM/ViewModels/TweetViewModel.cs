﻿using TwitterMVVM.MVVM.Model;
using System.Windows;

namespace TwitterMVVM.MVVM.ViewModels
{
    public class TweetViewModel
    {
        private readonly Tweet _tweet;

        public TweetViewModel(Tweet tweet)
        {
            _tweet = tweet;
        }

        public string AuthorImageURI
        {
            get { return _tweet.AuthorImageURI; }
        }

        public string AuthorName
        {
            // Format from Model: Username (Real Name)
            get { return ExtractUserName(_tweet.AuthorName).Trim(); }
        }

        public string Text
        {
            get { return _tweet.Text; }
        }

        public Visibility ShowImageNotFound
        {
            get { return string.IsNullOrEmpty(AuthorImageURI) ? Visibility.Visible : Visibility.Collapsed; }
        }

        private static string ExtractUserName(string tweetName)
        {
            return tweetName.Split("(".ToCharArray())[0];
        }
    }
}
