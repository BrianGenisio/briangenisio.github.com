﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using TwitterMVVM.MVVM.Model;

namespace TwitterMVVM.MVVM.ViewModels
{
    public class TwitterSearchViewModel : INotifyPropertyChanged
    {
        private readonly ITwitterModel _model;

        public TwitterSearchViewModel(ITwitterModel model)
        {
            if(model == null) throw new ArgumentNullException("model");

            _model = model;

            Tweets = new ObservableCollection<TweetViewModel>();
            SearchCommand = new DelegateCommand<object>(ExecuteSearch, x => SearchText.Length > 0);
        }

        public TwitterSearchViewModel()
            : this(new TwitterModel()) //this(new CannedDataModel())
        {}

        private void ExecuteSearch(object obj)
        {
            SearchStatus = "Searching Twitter...";
            Tweets.Clear();
            _model.SearchTwitter(SearchText, SearchComplete);
        }

        private void SearchComplete(IEnumerable<Tweet> tweets)
        {
            SearchStatus = string.Empty;

            foreach (var tweet in tweets)
                Tweets.Add(new TweetViewModel(tweet));
        }

        private string _searchText = string.Empty;
        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;
                OnPropertyChanged("SearchText");
                SearchCommand.NotifyCanExecuteChanged();
            }
        }

        private string _searchStatus;
        public string SearchStatus 
        {
            get { return _searchStatus; } 
            private set
            {
                _searchStatus = value;
                OnPropertyChanged("SearchStatus");
            }
        }

        public ObservableCollection<TweetViewModel> Tweets { get; private set; }
        public DelegateCommand<object> SearchCommand { get; private set; }

        protected void OnPropertyChanged(string propertyName)
        {
            var handlers = PropertyChanged;
            if(handlers != null)
                handlers(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}