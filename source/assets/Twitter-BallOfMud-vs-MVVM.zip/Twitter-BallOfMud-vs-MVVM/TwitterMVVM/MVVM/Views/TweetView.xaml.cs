﻿namespace TwitterMVVM.MVVM.Views
{
    public partial class TweetView
    {
        public TweetView()
        {
            InitializeComponent();
        }
    }
}
