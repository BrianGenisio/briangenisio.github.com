﻿
namespace TwitterMVVM.MVVM.Views
{
    public partial class TwitterSearchView
    {
        public TwitterSearchView()
        {
            InitializeComponent();
        }
    }
}