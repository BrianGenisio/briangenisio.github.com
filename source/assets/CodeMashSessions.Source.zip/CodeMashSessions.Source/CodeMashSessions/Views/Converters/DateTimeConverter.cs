﻿
using System.Windows.Data;
using System;
using System.Windows;
namespace CodeMashSessions.Views.Converters
{
    public class DateTimeConverter : IValueConverter
    {
        public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            DateTime time = (DateTime)value;
            string format = parameter as string;

            if (string.IsNullOrEmpty(format))
                return time.ToString();

            return time.ToString(format);
        }

        public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }
    }
}
