﻿using System.Windows.Data;
using System.Windows;

namespace CodeMashSessions.Views.Converters
{
    public class StringExistsToVisibility : ObjectExistsToVisibility
    {
        protected override bool HasValue(object value)
        {
            return !string.IsNullOrEmpty(value as string);
        }
    }
}
