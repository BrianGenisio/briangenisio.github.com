﻿
using System.Windows.Data;
using System.Windows;
namespace CodeMashSessions.Views.Converters
{
    public class ObjectExistsToVisibility : IValueConverter
    {
        public object Convert(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var reverse = parameter is string && (parameter as string).ToLower() == "reverse";
            bool hasValue = HasValue(value);

            if (reverse)
                hasValue = !hasValue;

            return hasValue ? Visibility.Visible : Visibility.Collapsed;
        }

        protected virtual bool HasValue(object value)
        {
            return value != null;
        }

        public object ConvertBack(object value, System.Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }
    }
}
