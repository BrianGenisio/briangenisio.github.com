﻿
using System.Windows.Threading;
using System.Collections.Generic;
using System.Windows;
using System;
using System.Linq;

using System.Windows.Controls;
using Blacklight.Controls;

using CodeMashSessions.Helpers;

namespace CodeMashSessions.Controls
{
    public class AnimatingStackPanel : AnimatedLayoutPanel
    {
        protected override Size MeasureOverride(Size availableSize)
        {
            Children.Cast<FrameworkElement>().Each(child => child.Width = this.ActualWidth);

            return base.MeasureOverride(availableSize);
        }
    }
}
