﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.Scheduler;

namespace CodeMashSessions.Controls.AttachedBehaviors
{
    public class Scheduler
    {
        private static DependencyProperty VisibleDateBehaviorProperty =
            DependencyProperty.RegisterAttached(
            "VisibleDateBehavior",
            typeof(SchedulerVisibleDateBehavior),
            typeof(RadScheduler),
            null);

        public static DependencyProperty VisibleDateProperty =
            DependencyProperty.RegisterAttached(
                "VisibleDate",
                typeof(DateTime),
                typeof(Scheduler),
                new PropertyMetadata(OnSetVisibleDate));

        public static void SetVisibleDate(RadScheduler scheduler, DateTime date) { scheduler.SetValue(VisibleDateProperty, date); }
        public static DateTime GetVisibleDate(RadScheduler scheduler) { return (DateTime)scheduler.GetValue(VisibleDateProperty); }

        private static void OnSetVisibleDate(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs args)
        {
            var target = dependencyObject as RadScheduler;
            if (target == null)
                return;

            var behavior = GetOrCreateBehavior(target);
            behavior.VisibleDate = (DateTime)args.NewValue;
        }

        private static SchedulerVisibleDateBehavior GetOrCreateBehavior(RadScheduler scheduler)
        {
            var behavior = scheduler.GetValue(VisibleDateBehaviorProperty) as SchedulerVisibleDateBehavior;
            if (behavior == null)
            {
                behavior = new SchedulerVisibleDateBehavior(scheduler);
                scheduler.SetValue(VisibleDateBehaviorProperty, behavior);
            }
            return behavior;
        }

        public class SchedulerVisibleDateBehavior
        {
            private readonly RadScheduler _target;
            private  DateTime _visibleDate;

            public SchedulerVisibleDateBehavior(RadScheduler target)
            {
                _target = target;
                _target.Loaded += Calendar_Loaded;
            }

            public DateTime VisibleDate
            {
                get { return _visibleDate; }
                set
                {
                    _visibleDate = value;
                    SetVisibleDate(value);
                }
            }

            private bool _loaded = false;
            void Calendar_Loaded(object sender, RoutedEventArgs e)
            {
                _target.Loaded -= Calendar_Loaded;
                _loaded = true;
            }

            public void SetVisibleDate(DateTime date)
            {
                if (_loaded)
                    _target.SetFirstVisibleDate(date);
                else
                    _target.SelectedTimeSlot = new TimeSlot(date, TimeSpan.FromMinutes(30));
            }
        }
    }
}
