﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CodeMashSessions.Controls.AttachedBehaviors
{
    public static class Update
    {
        private static DependencyProperty WhenTextChangedBehaviorProperty =
            DependencyProperty.RegisterAttached(
            "WhenTextChangedBehavior",
            typeof(UpdateWhenTextChangedBehavior),
            typeof(TextBox),
            null);

        public static DependencyProperty WhenTextChangedProperty =
            DependencyProperty.RegisterAttached(
                "WhenTextChanged",
                typeof(bool),
                typeof(Update),
                new PropertyMetadata(OnSetWhenTextChanged));

        public static void SetWhenTextChanged(TextBox textBox, bool value) { textBox.SetValue(WhenTextChangedProperty, value); }
        public static bool GetWhenTextChanged(TextBox textBox) { return (bool)textBox.GetValue(WhenTextChangedProperty); }

        private static void OnSetWhenTextChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs args)
        {
            var target = dependencyObject as TextBox;
            if (target == null)
                return;

            if ((bool)args.NewValue)
                GetOrCreateBehavior(target);
            else
                RemoveBehavior(target);
        }

        private static void GetOrCreateBehavior(TextBox textBox)
        {
            var behavior = textBox.GetValue(WhenTextChangedBehaviorProperty) as UpdateWhenTextChangedBehavior;
            if (behavior == null)
            {
                behavior = new UpdateWhenTextChangedBehavior(textBox);
                textBox.SetValue(WhenTextChangedBehaviorProperty, behavior);
            }
        }

        private static void RemoveBehavior(TextBox textBox)
        {
            var behavior = textBox.GetValue(WhenTextChangedBehaviorProperty) as UpdateWhenTextChangedBehavior;
            if (behavior != null)
            {
                behavior.Disengage();
            }

            textBox.SetValue(WhenTextChangedBehaviorProperty, null);
        }

    }

    public class UpdateWhenTextChangedBehavior
    {
        private readonly TextBox _target;

        public UpdateWhenTextChangedBehavior(TextBox target)
        {
            _target = target;
            _target.TextChanged += target_TextChanged;
        }

        void target_TextChanged(object sender, TextChangedEventArgs e)
        {
            var binding = _target.GetBindingExpression(TextBox.TextProperty);
            if (binding == null) return;

            binding.UpdateSource();
        }

        public void Disengage()
        {
            _target.TextChanged -= target_TextChanged;
        }

    }
}
