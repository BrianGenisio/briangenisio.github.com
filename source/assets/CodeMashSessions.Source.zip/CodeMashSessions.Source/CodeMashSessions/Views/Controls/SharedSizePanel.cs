﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CodeMashSessions.Controls
{
	/// <summary> Content container control which sizes it's width and/or height to a group. </summary>
	public class SharedSizePanel : ContentPresenter
	{
		public static readonly DependencyProperty WidthGroupProperty = DependencyProperty.Register("WidthGroup", typeof(SharedSizeGroup), typeof(SharedSizePanel), new PropertyMetadata(null, new PropertyChangedCallback(WidthGroupChanged)));

		/// <summary> Specifies the shared size group with which to synchronize the width. </summary>
		public SharedSizeGroup WidthGroup
		{
			get { return (SharedSizeGroup)GetValue(WidthGroupProperty); }
			set { SetValue(WidthGroupProperty, value); }
		}

		/// <summary> Handles WidthGroup changes by unregistering from the old group and registering with the new. </summary>
		private static void WidthGroupChanged(DependencyObject ASender, DependencyPropertyChangedEventArgs AArgs)
		{
			SharedSizePanel LThis = (SharedSizePanel)ASender;

			SharedSizeGroup LGroup = (SharedSizeGroup)AArgs.OldValue;
			if (LGroup != null && LThis.HeightGroup != LGroup)
				LGroup.UnregisterPanel(LThis);

			LGroup = (SharedSizeGroup)AArgs.NewValue;
			if (LGroup != null)
				LGroup.RegisterPanel(LThis);
		}

		public static readonly DependencyProperty HeightGroupProperty = DependencyProperty.Register("HeightGroup", typeof(SharedSizeGroup), typeof(SharedSizePanel), new PropertyMetadata(null, new PropertyChangedCallback(HeightGroupChanged)));

		/// <summary> Specifies the shared size group with which to synchronize the height. </summary>
		public SharedSizeGroup HeightGroup
		{
			get { return (SharedSizeGroup)GetValue(HeightGroupProperty); }
			set { SetValue(HeightGroupProperty, value); }
		}

		/// <summary> Handles HeightGroup changes by unregistering from the old group and registering with the new. </summary>
		private static void HeightGroupChanged(DependencyObject ASender, DependencyPropertyChangedEventArgs AArgs)
		{
			SharedSizePanel LThis = (SharedSizePanel)ASender;

			SharedSizeGroup LGroup = (SharedSizeGroup)AArgs.OldValue;
			if (LGroup != null && LThis.WidthGroup != LGroup)
				LGroup.UnregisterPanel(LThis);

			LGroup = (SharedSizeGroup)AArgs.NewValue;
			if (LGroup != null)
				LGroup.RegisterPanel(LThis);
		}

		/// <summary> Performs measurement utilizing a shared width and/or height. </summary>
		protected override Size MeasureOverride(Size AAvailableSize)
		{
			if (VisualTreeHelper.GetChildrenCount(this) >= 0)
			{
				// Measure the child - not as simple as acccessing the Content as that is not our true Child in the visual tree
				UIElement LChild = (UIElement)VisualTreeHelper.GetChild(this, 0);
				LChild.Measure(AAvailableSize);
				Size LChildSize = LChild.DesiredSize;
				
				// Measure using the group for width and/or height
				Size LShared = new Size(0, 0);
				if (WidthGroup != null)
					LShared = WidthGroup.Measure(this, LChildSize);
				if (HeightGroup != null)
				{
					if (HeightGroup != WidthGroup)
						LShared.Height = HeightGroup.Measure(this, LChildSize).Height;
				}
				else
					LShared.Height = 0;
				
				// Return the greater of the child and the group's dimensions
				return new Size(Math.Max(LChildSize.Width, LShared.Width), Math.Max(LChildSize.Height, LShared.Height));
			}
			else
				return base.MeasureOverride(AAvailableSize);
		}
	}
}
