﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Runtime.Serialization;

namespace CodeMashSessions.Helpers
{
    public static class Extensions
    {
        public static void AddRange<T>(this ICollection<T> collection, IEnumerable<T> items)
        {
            items.Each(collection.Add);
        }

        public static void RemoveRange<T>(this ICollection<T> collection, IEnumerable<T> items)
        {
            items.ToArray().Each(item => collection.Remove(item));
        }

        public static void Each<T>(this IEnumerable<T> items, Action<T> action)
        {
            foreach (var item in items)
                action(item);
        }

        public static IEnumerable<T> Append<T>(this IEnumerable<T> set, T end)
        {
            return set.Concat(new[] { end });
        }

        public static IEnumerable<T> Prepend<T>(this IEnumerable<T> set, T first)
        {
            return new[] { first }.Concat(set);
        }

        public static void Raise(this EventHandler handler, object sender)
        {
            var handlers = handler;
            if (handlers != null)
                handlers(sender, EventArgs.Empty);
        }

        public static Stream Serialize<T>(this T value)
        {
            var serializer = new DataContractSerializer(typeof(T));
            var result = new MemoryStream();
            serializer.WriteObject(result, value);
            result.Flush();
            result.Position = 0;
            return result;
        }

        public static string AsString(this Stream stream)
        {
            using (var reader = new StreamReader(stream))
                return reader.ReadToEnd();
        }

        public static T Deserialize<T>(this string value)
        {
            var serializer = new DataContractSerializer(typeof(T));

            using(var memStream = new MemoryStream())
            using (var writer = new StreamWriter(memStream))
            {
                writer.Write(value);
                writer.Flush();
                memStream.Position = 0;

                return (T)serializer.ReadObject(memStream);
            }
        }

        public static IEnumerable<T> AsSet<T>(this T item)
        {
            yield return item;
        }

        public static string Join(this IEnumerable<string> strings, string delimieter)
        {
            return string.Join(delimieter, strings.ToArray());
        }
    }
}
