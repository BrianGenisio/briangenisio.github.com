﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CodeMashSessions.Helpers
{
    public class Lazy<T> where T : class
    {
        private T _value;

        public T Value
        {
            get
            {
                if (_value == null)
                {
                    _value = Activator.CreateInstance(typeof(T)) as T;
                }
                return _value;
            }
        }

        public bool HasValue
        {
            get { return _value != null; }
        }

    }
}
