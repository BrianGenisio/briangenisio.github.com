﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using CodeMashSessions.Helpers;
using System.Collections.ObjectModel;
using CodeMashSessions.Model;
using System.Collections.Generic;
using Microsoft.Practices.Composite.Events;
using CodeMashSessions.ViewModels.Events;
using CodeMashSessions.Service;

namespace CodeMashSessions.ViewModels
{
    public class SessionsViewModel : ViewModel
    {
        private readonly IList<Session> _allSessions = new List<Session>();
        private Predicate<Session> _filter;

        public SessionsViewModel(ICodeMashService service, IEventAggregator eventAggregator)
        {
            _filter = session => true;

            eventAggregator.GetEvent<FilterSessions>().Subscribe(FilterSessions);

            Sessions = new ObservableCollection<Session>();

            if (IsDesignMode)
                PopulateFakeData();
            else
                service.GetSessions(SessionsReceived);
        }

        public SessionsViewModel()
            : this(App.CodeMashService, App.EventAggregator)
        { }

        private void PopulateFakeData()
        {
            Sessions.Add(new Session
            {
                Title = "This is a session title 1",
                Difficulty = "Hard",
                Technology = "Java",
                Track = "MyTrack",
                Abstract = "Building a desktop application is a hard task, there are some many things to keep track of that many projects simply fail to meet their goals. Setting up the project structure keeping each artifact on a well identified location given its responsibility and type, defining the base schema for managing the application's life cycle, making sure the build is properly setup, and more. These are recurring tasks that should be handled by a tool or better yet, a framework. Griffon is such a framework. Inspired by the Grails framework Griffon aims to bring the same productivity gains to desktop development, there are so many traits shared by both frameworks that a Grails developer should be able to pick up the pace quickly.",
                Speaker = new Speaker
                {
                    Name = "Brian Genisio",
                    Biography = "Brian Genisio currently is employed as a Senior Software Developer for Siemens Medical Solutions in Ann Arbor, MI. For almost 10 years, Brian has worked both in Linux and in Windows, covering many languages and technologies along the way. He has been developing with C# in .NET for over 3 years and he strongly believes in TDD and CI practices. Brian loves to learn new ideas and talk about them with others.",
                    PhotoURL = "http://www.gravatar.com/avatar/170325813beddd7418a3b55ffbf378f9?s=128&d=identicon&r=PG"
                }
            });
            Sessions.Add(new Session
            {
                Title = "This is a session title 2",
                Difficulty = "Hard",
                Technology = "Java",
                Track = "MyTrack",
                Abstract = "Building a desktop application is a hard task, there are some many things to keep track of that many projects simply fail to meet their goals. Setting up the project structure keeping each artifact on a well identified location given its responsibility and type, defining the base schema for managing the application's life cycle, making sure the build is properly setup, and more. These are recurring tasks that should be handled by a tool or better yet, a framework. Griffon is such a framework. Inspired by the Grails framework Griffon aims to bring the same productivity gains to desktop development, there are so many traits shared by both frameworks that a Grails developer should be able to pick up the pace quickly."
            });
        }

        public void SessionsReceived(IEnumerable<Session> sessions)
        {
            _allSessions.Clear();
            _allSessions.AddRange(sessions);
            
            UpdateSessions();
        }

        public void FilterSessions(Predicate<Session> filter)
        {
            _filter = filter;
            UpdateSessions();
        }

        private void UpdateSessions()
        {
            var itemsToShow = _allSessions.Where(session => _filter(session));
            var itemsToRemove = Sessions.Where(session => !itemsToShow.Contains(session));
            var itemsToAdd = itemsToShow.Where(session => !Sessions.Contains(session));

            Sessions.RemoveRange(itemsToRemove);
            Sessions.AddRange(itemsToAdd);
        }
        
        public ObservableCollection<Session> Sessions { get; private set; }

    }
}
