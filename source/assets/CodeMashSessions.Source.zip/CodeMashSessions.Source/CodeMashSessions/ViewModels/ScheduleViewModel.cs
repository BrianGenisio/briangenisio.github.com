﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using CodeMashSessions.Helpers;
using Microsoft.Practices.Composite.Events;
using CodeMashSessions.ViewModels.Events;
using System.Collections.Generic;
using CodeMashSessions.Model;
using Telerik.Windows.Controls.Scheduler;
using Microsoft.Practices.Composite.Presentation.Commands;
using CodeMashSessions.Views;
using CodeMashSessions.Service;
using Telerik.Windows.Controls;

namespace CodeMashSessions.ViewModels
{
    public class ScheduleViewModel : ViewModel
    {
        private readonly DateTime _startDate = DateTime.Parse("1/14/2010");
        private readonly DateTime _endDate = DateTime.Parse("1/15/2010");
        private readonly ICodeMashService _service;
        private readonly IResourceDictionary _resourceDictionary;

        public class CodemashAppointment : Appointment
        {
            private readonly IResourceDictionary _resourceDictionary;
            private readonly ICodeMashService _service;

            public CodemashAppointment(ICodeMashService service, IResourceDictionary resourceDictionary)
            {
                _resourceDictionary = resourceDictionary;
                _service = service;
            }

            public string Room
            {
                get
                {
                    var resource = this.Resources.GetResourceByType("Room");
                    if (resource != null)
                    {
                        return this.Resources.GetResourceByType("Room").ResourceName;
                    }
                    return null;
                }
                set
                {
                    if (value == "ALL")
                        SetAllResources();
                    else
                        this.Resources.Add(new Resource(value, "Room"));

                    OnPropertyChanged("Room");
                }
            }

            public Session Session { get; set; }

            private void AllRooms(Action<IEnumerable<string>> whenComplete)
            {
                _service.GetSessions(sessions =>
                    whenComplete(sessions.Select(s => s.Room).Distinct()));
            }

            private void SetAllResources()
            {
                AllRooms(rooms =>
                    {
                        rooms.Each(room => Resources.Add(new Resource(room, "Room")));
                        Category = new Category("All Rooms", _resourceDictionary["AllRoomsBrush"] as SolidColorBrush);
                    });
            }
        }

        public ScheduleViewModel(ICodeMashService service, IResourceDictionary resourceDictionary)
        {
            _service = service;
            _resourceDictionary = resourceDictionary;

            Appointments = new AppointmentCollectionView();
            
            VisibleDate = _startDate;

            SetDateCommand = new DelegateCommand<string>(date => VisibleDate = DateTime.Parse(date));

            if (IsDesignMode)
                PopulateFakeData();
            else
            {
                _service.GetSessions(SessionsReceived);
                _service.GetUnsessions(UnSessionsReceived);
            }
        }

        public ScheduleViewModel()
            : this(App.CodeMashService, App.ResourceDictionary)
        { }

        private void PopulateFakeData()
        {
            Appointments.Add(new Appointment
            {
                Start = DateTime.Parse("1/14/2010 11:30 AM"),
                End = DateTime.Parse("1/14/2010 12:30 PM"),
                Subject = "My Subject"
            });

            Appointments.Add(new Appointment
            {
                Start = DateTime.Parse("1/14/2010 11:30 AM"),
                End = DateTime.Parse("1/14/2010 12:30 PM"),
                Subject = "My Subject 2"
            });
        }

        public void SessionsReceived(IEnumerable<Session> sessions)
        {
            var appointments = sessions.Select(session => new CodemashAppointment(_service, _resourceDictionary)
            {
                Start = session.Start,
                End = session.Start + TimeSpan.FromMinutes(60),
                Subject = string.IsNullOrEmpty(session.Title) ? "TBD" : session.Title,
                Session = session,
                Body = session.Abstract,
                Room = session.Room,
            });

            appointments.Each(Appointments.Add);
        }

        public void UnSessionsReceived(IEnumerable<UnSession> unSessions)
        {
            var appointments = unSessions.Select(session => new CodemashAppointment(_service, _resourceDictionary)
            {
                Start = session.Start,
                End = session.End,
                Subject = session.Title,
                Room = "ALL"
            });

            appointments.Each(Appointments.Add);
        }

        public AppointmentCollectionView Appointments { get; private set; }
        public DelegateCommand<string> SetDateCommand { get; private set; }

        private DateTime _visibleDate;
        public DateTime VisibleDate
        {
            get { return _visibleDate; }
            set
            {
                _visibleDate = value;
                RaisePropertyChanged("VisibleDate");
            }
        }

    }
}
