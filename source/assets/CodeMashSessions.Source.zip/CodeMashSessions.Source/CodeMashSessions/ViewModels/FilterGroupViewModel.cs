﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.ComponentModel;
using CodeMashSessions.Model;
using CodeMashSessions.Helpers;
using System.Collections.ObjectModel;


namespace CodeMashSessions.ViewModels
{
    public class FilterGroupViewModel<T> : ViewModel
    {
        private readonly Func<T, string> _getProperty;

        public FilterGroupViewModel(string filterName, IEnumerable<T> items, Func<T, string> getProperty)
        {
            _getProperty = getProperty;
            FilterName = filterName;

            SetupOptions(items);
        }

        private void SetupOptions(IEnumerable<T> items)
        {
            var options = items.Select(_getProperty).Distinct().Prepend("All");

            Options = new ObservableCollection<FilterOption>();
            Options.AddRange(options.Where(o => !string.IsNullOrEmpty(o)).Select(o => new FilterOption(FilterName, o)));
            Options.Each(o => o.PropertyChanged += Option_SelectedChanged);
            Options.First().Selected = true;
        }

        private void Option_SelectedChanged(object sender, PropertyChangedEventArgs args)
        {
            RaisePropertyChanged("Filter");
            RaisePropertyChanged("Selected");
        }

        public Predicate<T> Filter
        {
            get { return item => Selected == "All" ? true : _getProperty(item) == Selected; }
        }

        public string Selected
        {
            get
            {
                var selected = Options.FirstOrDefault(o => o.Selected);
                
                if (selected == null) 
                    return "All";

                return selected.Value;
            }
        }

        public ObservableCollection<FilterOption> Options { get; private set; }
        public string FilterName { get; private set; }
    }
}
