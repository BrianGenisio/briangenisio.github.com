﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using CodeMashSessions.Helpers;
using System.Collections.Generic;
using CodeMashSessions.Model;
using Microsoft.Practices.Composite.Events;
using CodeMashSessions.ViewModels.Events;
using System.ComponentModel;
using Microsoft.Practices.Composite.Presentation.Commands;
using CodeMashSessions.Service;

namespace CodeMashSessions.ViewModels
{
    public class FilterPanelViewModel : ViewModel
    {
        private readonly IEventAggregator _eventAggregator;

        public FilterPanelViewModel(ICodeMashService service, IEventAggregator eventAggregator)
        {
            _eventAggregator = eventAggregator;
            
            Filters = new ObservableCollection<FilterGroupViewModel<Session>>();

            if (IsDesignMode)
                PopulateFakeData();
            else
                service.GetSessions(SessionsReceived);
        }

        public FilterPanelViewModel()
            : this(App.CodeMashService, App.EventAggregator)
        { }

        private void PopulateFakeData()
        {
            SessionsReceived(new[] {
                new Session { Technology = ".net", Difficulty = "Hard", Track = "Architecture" }
            });
        }

        public void SessionsReceived(IEnumerable<Session> sessions)
        {
            Filters.Add(new FilterGroupViewModel<Session>("Technologies", sessions, session => session.Technology));
            Filters.Add(new FilterGroupViewModel<Session>("Difficulties", sessions, session => session.Difficulty));
            Filters.Add(new FilterGroupViewModel<Session>("Tracks", sessions, session => session.Track));

            Filters.Each(filter => filter.PropertyChanged += FilterChanged_PropertyChanged);
        }

        void FilterChanged_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName != "Filter") return;

            SendFilter();
        }

        private void SendFilter()
        {
            var filters = Filters.Select(x => x.Filter).Append(SearchFilter);
            _eventAggregator.GetEvent<FilterSessions>().Publish(Merge(filters));
        }

        private bool SearchFilter(Session session)
        {
            if (string.IsNullOrEmpty(SearchText))
                return true;

            return session.Abstract.ToLower().Contains(SearchText.ToLower());
        }

        private Predicate<Session> Merge(IEnumerable<Predicate<Session>> filters)
        {
            return session =>
                {
                    foreach (var filter in filters)
                    {
                        if (!filter(session))
                            return false;
                    }

                    return true;
                };
        }

        public ObservableCollection<FilterGroupViewModel<Session>> Filters { get; private set; }
        public DelegateCommand<object> Search { get; private set; }

        private string _searchText = string.Empty;
        public string SearchText
        {
            get { return _searchText; }
            set
            {
                _searchText = value;
                RaisePropertyChanged("SearchText");
                SendFilter();
            }
        }
    }
}
