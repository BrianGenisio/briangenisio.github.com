﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using CodeMashSessions.Helpers;

namespace CodeMashSessions.ViewModels
{
    public class FilterOption : PropertyNotifier
    {
        public FilterOption(string groupName, string value)
        {
            FilterName = groupName;
            Value = value;
        }

        private bool _selected;
        public bool Selected
        {
            get { return _selected; }
            set
            {
                _selected = value;
                RaisePropertyChanged("Selected");
            }
        }

        public string FilterName { get; private set; }
        public string Value { get; private set; }
    }
}
