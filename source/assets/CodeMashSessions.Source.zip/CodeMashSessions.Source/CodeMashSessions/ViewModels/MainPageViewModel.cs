﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using CodeMashSessions.Service;
using System.Collections;
using CodeMashSessions.Model;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using CodeMashSessions.Helpers;
using Microsoft.Practices.Composite.Events;
using CodeMashSessions.ViewModels.Events;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace CodeMashSessions.ViewModels
{
    public class MainPageViewModel : ViewModel
    {
        private readonly ICodeMashService _service;
        private readonly IEventAggregator _eventAggregator;

        public MainPageViewModel(ICodeMashService service, IEventAggregator eventAggregator)
        {
            _service = service;
            _eventAggregator = eventAggregator;

            Busy = false;
            SwitchView = new DelegateCommand<string>(eventAggregator.GetEvent<ChangeView>().Publish);

            if (!IsDesignMode)
                PopulateRealData();
        }

        public MainPageViewModel()
            : this(App.CodeMashService, App.EventAggregator)
        { }

        private void PopulateRealData()
        {
            Busy = true;
            _service.GetSessions(SessionsReceived);
        }

        private void SessionsReceived(IEnumerable<Session> sessions)
        {
            Busy = false;
            SwitchView.Execute(string.Empty);
        }

        private bool _busy;
        public bool Busy
        {
            get { return _busy; }
            set
            {
                _busy = value;
                RaisePropertyChanged("Busy");
            }
        }

        public DelegateCommand<string> SwitchView { get; private set; }
    }
}
