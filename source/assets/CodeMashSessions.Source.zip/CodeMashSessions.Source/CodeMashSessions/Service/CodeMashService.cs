﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using CodeMashSessions.Model;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Windows.Browser;
using CodeMashSessions.Helpers;

namespace CodeMashSessions.Service
{
    public class CodeMashService : ICodeMashService
    {
        private readonly IWebReceiver _webReceiver;

        private IList<Session> _sessions;
        private Dictionary<string, Speaker> _speakers;

        public CodeMashService(IWebReceiver receiver)
        {
            _webReceiver = receiver;
        }

        public CodeMashService()
            : this(new WebReceiver())
        { }

        public void GetSessions(Action<IEnumerable<Session>> whenComplete)
        {
            if (_sessions != null)
            {
                whenComplete(_sessions);
                return;
            }

            RetrieveSpeakerImages(
                () => RetrieveSpeakers(
                    () => RetrieveSessions(whenComplete)));
        }

        public void GetUnsessions(Action<IEnumerable<UnSession>> whenComplete)
        {
            _webReceiver.GetString(new Uri("UnSessions.xml", UriKind.Relative), result => whenComplete(result.Deserialize<List<UnSession>>()));
        }

        private void RetrieveSessions(Action<IEnumerable<Session>> whenComplete)
        {
            _webReceiver.GetString(new Uri("http://www.codemash.org/rest/sessions"), result =>
                {
                    _sessions = ParseSessions(result).ToList();
                    whenComplete(_sessions);
                });
        }

        private void RetrieveSpeakers(Action whenComplete)
        {
            _webReceiver.GetString(new Uri("http://www.codemash.org/rest/speakers"), result =>
                {
                    StoreSpeakers(ParseSpeakers(result));
                    whenComplete();
                });
        }

        private void RetrieveSpeakerImages(Action whenComplete)
        {
            _webReceiver.GetString(new Uri("SpeakerImages.xml", UriKind.Relative), result =>
            {
                _speakerImages = result.Deserialize<Dictionary<string, string>>();
                whenComplete();
            });
        }

        private string StripLeadingSlash(string value)
        {
            if (value.StartsWith("/"))
                return value.Substring(1);
            return value;
        }

        private void StoreSpeakers(IEnumerable<Speaker> speakers)
        {
            _speakers = speakers.ToDictionary(speaker => SpeakerKey(speaker.SpeakerURI));
        }

        private string SpeakerKey(string speakerURI)
        {
            return StripLeadingSlash(speakerURI).ToLower();
        }

        private Speaker FindSpeaker(string speakerURI)
        {
            var key = SpeakerKey(speakerURI);

            if (_speakers == null) return null;
            if (!_speakers.ContainsKey(key)) return null;

            return _speakers[key];
        }

        private string Value(XElement element, string name)
        {
            var child = element.Element(name);
            return child != null ? Decode(child.Value) : string.Empty;
        }

        private string Decode(string value)
        {
            value = HttpUtility.HtmlDecode(value);
            value = value.Replace("<BR>", "\r\n");
            value = value.Replace("<br>", "\r\n");
            return value;
        }

        private Uri SessionUri(XElement element, string name)
        {
            return SessionUri(Value(element, name));
        }

        private Uri SessionUri(string value)
        {
            return !string.IsNullOrEmpty(value) ? new Uri("http://www.codemash.org" + value) : null;
        }

        private Uri Uri(XElement element, string name)
        {
            var value = Value(element, name);
            return !string.IsNullOrEmpty(value) ? new Uri(value) : null;
        }

        private IEnumerable<Session> ParseSessions(string xml)
        {
            var xDoc = XDocument.Parse(xml);

            return from session in xDoc.Root.Elements("Session")
                   select new Session
                   {
                       SessionURI = SessionUri(session, "URI"),
                       Title = Value(session, "Title"),
                       Abstract = Value(session, "Abstract"),
                       Start = DateTime.Parse(Value(session, "Start")),
                       Room = Value(session, "Room"),
                       Difficulty = Value(session, "Difficulty"),
                       Speaker = FindSpeaker(Value(session, "SpeakerURI")),
                       Technology = Value(session, "Technology"),
                       Track = Value(session, "Track")
                   };
        }

        private IEnumerable<Speaker> ParseSpeakers(string xml)
        {
            var xDoc = XDocument.Parse(xml);

            return from speaker in xDoc.Root.Elements("Speaker")
                   select new Speaker
                   {
                       Name = Value(speaker, "Name"),
                       Biography = Value(speaker, "Biography"),
                       Sessions = from sessionURI in speaker.Element("Sessions").Elements("SessionURI")
                                  select SessionUri(sessionURI.Value),
                       TwitterHandle = Value(speaker, "TwitterHandle"),
                       Blog = Uri(speaker, "BlogURL"),
                       PhotoURL = GetPhotoURL(Value(speaker, "SpeakerURI")),
                       SpeakerURI = Value(speaker, "SpeakerURI")
                   };
        }

        private string GetPhotoURL(string speakerURI)
        {
            if (_speakerImages.ContainsKey(speakerURI) && !string.IsNullOrEmpty(_speakerImages[speakerURI]))
                return _speakerImages[speakerURI];

            return null;
        }

        private Dictionary<string, string> _speakerImages;
    }
}
