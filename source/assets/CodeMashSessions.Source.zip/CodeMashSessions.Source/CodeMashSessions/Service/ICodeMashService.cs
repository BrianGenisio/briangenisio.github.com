﻿using System;
using CodeMashSessions.Model;
using System.Collections.Generic;
namespace CodeMashSessions.Service
{
    public interface ICodeMashService
    {
        void GetSessions(Action<IEnumerable<Session>> whenComplete);
        void GetUnsessions(Action<IEnumerable<UnSession>> whenComplete);
    }
}
