﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CodeMashSessions.Model
{
    public class UnSession
    {
        public UnSession() { }

        public UnSession(string title, DateTime start, DateTime end)
        {
            Title = title;
            Start = start;
            End = end;
        }

        public UnSession(string title, string start, string end)
            : this(title, DateTime.Parse(start), DateTime.Parse(end))
        { }

        public string Title { get; set; }
        public DateTime Start {get; set; }
        public DateTime End { get; set; }
    }
}
