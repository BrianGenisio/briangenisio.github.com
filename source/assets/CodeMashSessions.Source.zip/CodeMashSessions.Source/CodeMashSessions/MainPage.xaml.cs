﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using CodeMashSessions.Service;
using Telerik.Windows.Controls;
using CodeMashSessions.Views;
using CodeMashSessions.Views.Animations;
using CodeMashSessions.ViewModels;
using CodeMashSessions.Helpers;
using CodeMashSessions.ViewModels.Events;

namespace CodeMashSessions
{
    public partial class MainPage : UserControl
    {
        private PageTransition _transition;
        private readonly Lazy<ScheduleView> _schedule = new Lazy<ScheduleView>();
        private readonly Lazy<SessionsView> _sessions = new Lazy<SessionsView>();

        public MainPage()
        {
            InitializeComponent();

            SetupNavigationService();
            SetupTransition();

            App.EventAggregator.GetEvent<ChangeView>().Subscribe(ChangeView);
        }

        private void SetupNavigationService()
        {
            var navService = NavigationService.GetNavigationService();
            navService.Target = frameContainer;
            navService.RootPanel = frameContainer;
        }

        private void SetupTransition()
        {
            var mask1 = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(77, 8, 17, 48)) };
            var mask2 = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(77, 8, 17, 48)) };
            _transition = new PageTransition(frameContainer.ActualWidth, frameContainer, mask1, mask2);
            NavigationService.GetNavigationService().Transition = _transition;
        }

        private void Navigate(IFrame frame)
        {
            var navService = NavigationService.GetNavigationService();
            _transition.PageWidth = frameContainer.ActualWidth;
            navService.Navigate(frame);
        }

        public void ChangeView(string viewName)
        {
            Navigate(viewName == "Sessions" ? _sessions.Value :  (Frame)_schedule.Value);
        }
    }
}
