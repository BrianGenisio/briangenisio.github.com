﻿using System;
using System.Collections.Generic;
using CodeMashSessions.Model;
using CodeMashSessions.Service;
using CodeMashSessions.ViewModels;
using CodeMashSessions.ViewModels.Events;
using Microsoft.Practices.Composite.Events;
using Moq;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.ViewModels
{
    [TestFixture]
    public class MainPageViewModelTests : ViewModelTests<MainPageViewModel>
    {
        private ChangeView _changeViewEvent;
        private string _lastView;

        protected override void ConfigureEventAggregator(Mock<IEventAggregator> mockAggregator)
        {
            _changeViewEvent = new ChangeView();
            mockAggregator.Setup(ea => ea.GetEvent<ChangeView>()).Returns(_changeViewEvent);

            _lastView = null;
        }

        protected override MainPageViewModel CreateViewModel(Mock<ICodeMashService> mockService, Mock<IEventAggregator> mockAggregator)
        {
            return new MainPageViewModel(mockService.Object, mockAggregator.Object);
        }

        [Test]
        public void Busy_By_Default()
        {
            Assert.That(ViewModel.Busy, Is.True);
        }

        [Test]
        public void GetSessions_Is_Requested_At_Startup()
        {
            MockService.Verify(s => s.GetSessions(It.IsAny<Action<IEnumerable<Session>>>()));
        }

        [Test]
        public void When_Sessions_Are_Received_Busy_Is_False()
        {
            SessionsCallback(new Session[0]);

            Assert.That(ViewModel.Busy, Is.False);
        }

        public void ChangeView(string viewName)
        {
            _lastView = viewName;
        }
        
        [Test]
        public void WhenSessions_Are_Received_SwitchView_To_Default()
        {
            _changeViewEvent.Subscribe(ChangeView);

            SessionsCallback(new Session[0]);

            Assert.That(_lastView, Is.EqualTo(""));
        }

        [Test]
        public void When_SwitchView_Is_Executed_Event_Is_Fired()
        {
            _changeViewEvent.Subscribe(ChangeView);

            ViewModel.SwitchView.Execute("Foo");

            Assert.That(_lastView, Is.EqualTo("Foo"));
        }
    }
}
