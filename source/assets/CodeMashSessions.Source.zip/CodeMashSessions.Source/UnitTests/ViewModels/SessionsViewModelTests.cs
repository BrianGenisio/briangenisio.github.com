﻿using System;
using System.Collections.Generic;
using System.Linq;
using CodeMashSessions.Model;
using CodeMashSessions.Service;
using CodeMashSessions.ViewModels;
using CodeMashSessions.ViewModels.Events;
using CodeMashSessions.Helpers;
using Microsoft.Practices.Composite.Events;
using Moq;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.ViewModels
{
    [TestFixture]
    public class SessionsViewModelTests : ViewModelTests<SessionsViewModel>
    {
        private FilterSessions _filterSessionsEvent;
        private Predicate<Session> _lastFilter;

        protected override void ConfigureEventAggregator(Mock<IEventAggregator> mockAggregator)
        {
            _filterSessionsEvent = new FilterSessions();
            mockAggregator.Setup(ea => ea.GetEvent<FilterSessions>()).Returns(_filterSessionsEvent);
            _lastFilter = null;
        }

        protected override SessionsViewModel CreateViewModel(Mock<ICodeMashService> mockService, Mock<IEventAggregator> mockAggregator)
        {
            return new SessionsViewModel(mockService.Object, mockAggregator.Object);
        }

        [Test]
        public void GetSessions_Is_Requested_On_Startup()
        {
            MockService.Verify(s => s.GetSessions(It.IsAny<Action<IEnumerable<Session>>>()));
        }

        [Test]
        public void Sessions_Received_Make_Sessions_List()
        {
            var titles = new[] { "Foo", "Bar", "Baz" };
            var sessions = titles.Select(t => new Session { Title = t });
            SessionsCallback(sessions);

            Assert.That(ViewModel.Sessions.Count, Is.EqualTo(3));
            sessions.Each(s => Assert.That(ViewModel.Sessions.Any(vms => vms.Title == s.Title)));
        }

        [Test]
        public void Sending_Filter_Only_Shows_Filtered_Sessions()
        {
            var titles = new[] { "Foo", "Bar", "Baz" };
            SessionsCallback(titles.Select(t => new Session { Title = t }));

            _filterSessionsEvent.Publish(s => s.Title.StartsWith("B"));

            Assert.That(ViewModel.Sessions.Count, Is.EqualTo(2));
            Assert.That(ViewModel.Sessions.Any(s => s.Title == "Bar"));
            Assert.That(ViewModel.Sessions.Any(s => s.Title == "Baz"));
        }

        [Test]
        public void Sending_Filter_With_None_Clears_Sessions_List()
        {
            var titles = new[] { "Foo", "Bar", "Baz" };
            SessionsCallback(titles.Select(t => new Session { Title = t }));

            _filterSessionsEvent.Publish(s => false);

            Assert.That(ViewModel.Sessions.Count, Is.EqualTo(0));
        }

        [Test]
        public void Clearing_And_Adding_Via_Filter_Adds_Back_To_Sessions_List()
        {
            var titles = new[] { "Foo", "Bar", "Baz" };
            SessionsCallback(titles.Select(t => new Session { Title = t }));

            _filterSessionsEvent.Publish(s => false);
            _filterSessionsEvent.Publish(s => s.Title.StartsWith("F"));

            Assert.That(ViewModel.Sessions.Count, Is.EqualTo(1));
            Assert.That(ViewModel.Sessions[0].Title, Is.EqualTo("Foo"));
        }

    }
}
