﻿using System;
using System.Linq;
using System.Collections.Generic;
using CodeMashSessions.Model;
using CodeMashSessions.Service;
using CodeMashSessions.ViewModels;
using CodeMashSessions.ViewModels.Events;
using CodeMashSessions.Helpers;
using Microsoft.Practices.Composite.Events;
using Moq;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;


namespace UnitTests.ViewModels
{
    [TestFixture]
    public class FilterPanelViewModelTests : ViewModelTests<FilterPanelViewModel>
    {
        private FilterSessions _filterSessionsEvent;
        private Predicate<Session> _lastFilter;

        protected override void ConfigureEventAggregator(Mock<IEventAggregator> mockAggregator)
        {
            _filterSessionsEvent = new FilterSessions();
            mockAggregator.Setup(ea => ea.GetEvent<FilterSessions>()).Returns(_filterSessionsEvent);
            _lastFilter = null;
        }

        protected override FilterPanelViewModel CreateViewModel(Mock<ICodeMashService> mockService, Mock<IEventAggregator> mockAggregator)
        {
            return new FilterPanelViewModel(mockService.Object, mockAggregator.Object);
        }

        [Test]
        public void GetSessions_Is_Requested_On_Startup()
        {
            MockService.Verify(s => s.GetSessions(It.IsAny<Action<IEnumerable<Session>>>()));
        }

        [Test]
        public void Filters_Are_Added_When_Sessions_Are_Received()
        {
            Assert.That(ViewModel.Filters.Count, Is.EqualTo(0));

            SessionsCallback(new Session[0]);

            Assert.That(ViewModel.Filters.Count, Is.GreaterThan(0));
        }

        private FilterGroupViewModel<Session> FindFilterGroup(string name)
        {
            return ViewModel.Filters.First(f => f.FilterName == name);
        }

        private static void SetFilterGroup(FilterGroupViewModel<Session> filterGroup, string value)
        {
            filterGroup.Options.Each(o => o.Selected = false);
            filterGroup.Options.First(o => o.Value == value).Selected = true;
        }

        [Test]
        public void Validate_Technology_Filter()
        {
            var technologies = new[] { ".Net", "Java", "C#"};
            SessionsCallback(technologies.Select(x => new Session { Technology = x }));

            var filterGroup = FindFilterGroup("Technologies");
            SetFilterGroup(filterGroup, ".Net");

            Assert.That(filterGroup.Filter(new Session { Technology = ".Net" }), Is.True);
            Assert.That(filterGroup.Filter(new Session { Technology = "Java" }), Is.False);
        }

        [Test]
        public void Validate_Difficulties_Filter()
        {
            var difficulties = new[] { "Easy", "Medium", "Hard"};
            SessionsCallback(difficulties.Select(x => new Session { Difficulty = x }));

            var filterGroup = FindFilterGroup("Difficulties");
            SetFilterGroup(filterGroup, "Medium");

            Assert.That(filterGroup.Filter(new Session { Difficulty = "Easy" }), Is.False);
            Assert.That(filterGroup.Filter(new Session { Difficulty = "Medium" }), Is.True);
        }

        [Test]
        public void Validate_Tracks_Filter()
        {
            var tracks = new[] { "Development", "Processes", "Patterns" };
            SessionsCallback(tracks.Select(x => new Session { Track = x }));

            var filterGroup = FindFilterGroup("Tracks");
            SetFilterGroup(filterGroup, "Patterns");

            Assert.That(filterGroup.Filter(new Session { Track = "Development" }), Is.False);
            Assert.That(filterGroup.Filter(new Session { Track = "Patterns" }), Is.True);
        }

        public void ReceiveFilterEvent(Predicate<Session> filter)
        {
            _lastFilter = filter;
        }

        [Test]
        public void Modifying_Filter_Sends_FilterSession_Event()
        {
            var technologies = new[] { ".Net", "Java", "C#" };
            SessionsCallback(technologies.Select(x => new Session { Technology = x }));
            _filterSessionsEvent.Subscribe(ReceiveFilterEvent);

            Assert.That(_lastFilter, Is.Null);
            var filterGroup = ViewModel.Filters.First().Options.First().Selected = false;
            Assert.That(_lastFilter, Is.Not.Null);
        }

        [Test]
        public void Filters_Are_Merged_When_They_Change()
        {
            _filterSessionsEvent.Subscribe(ReceiveFilterEvent);
            var technologies = new[] { ".Net", "Java", "C#" };
            var difficulties = new[] { "Easy", "Medium", "Hard" };
            var sessions = from t in technologies
                           from d in difficulties
                           select new Session { Technology = t, Difficulty = d };

            SessionsCallback(sessions);

            SetFilterGroup(FindFilterGroup("Technologies"), "Java");
            SetFilterGroup(FindFilterGroup("Difficulties"), "Medium");

            Assert.That(_lastFilter(new Session { Technology = "Java", Difficulty = "Hard" }), Is.False);
            Assert.That(_lastFilter(new Session { Technology = "C#", Difficulty = "Medium" }), Is.False);
            Assert.That(_lastFilter(new Session { Technology = "Java", Difficulty = "Medium" }), Is.True);
        }

        [Test]
        public void Setting_SearchText_Fires_Filter_Change()
        {
            _filterSessionsEvent.Subscribe(ReceiveFilterEvent);

            Assert.That(_lastFilter, Is.Null);
            ViewModel.SearchText = "Foo";
            Assert.That(_lastFilter, Is.Not.Null);

        }

        [Test]
        public void Test_Search_Filter_Filters_Abstract()
        {
            _filterSessionsEvent.Subscribe(ReceiveFilterEvent);

            ViewModel.SearchText = "Foo";

            Assert.That(_lastFilter(new Session { Abstract = "We have some delicious foo for you" }), Is.True);
            Assert.That(_lastFilter(new Session { Abstract = "But no bar for you" }), Is.False);
        }

    }
}
