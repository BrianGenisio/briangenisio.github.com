﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using NUnit.Framework;
using CodeMashSessions.Model;
using System.Collections.Generic;
using CodeMashSessions.ViewModels;
using CodeMashSessions.Helpers;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.ViewModels
{
    [TestFixture]
    public class FilterGroupViewModelTests
    {
        public class MyClass
        {
            public string Name { get; set; }
        }

        private IEnumerable<MyClass> SessionsWithNames(params string[] names)
        {
            return names.Select(name => new MyClass { Name = name });
        }

        private FilterGroupViewModel<MyClass> FilterPanel(params string[] names)
        {
            return new FilterGroupViewModel<MyClass>("Names", SessionsWithNames(names), x => x.Name);
        }

        [Test]
        public void FilterName_Is_Set_From_Constructor()
        {
            var viewModel = FilterPanel("A", "B", "C");

            Assert.That(viewModel.FilterName, Is.EqualTo("Names"));
        }

        [Test]
        public void Options_Are_Set_Based_On_Filter_Property()
        {
            var viewModel = FilterPanel("A", "B", "C");

            Assert.That(viewModel.Options.Count(x => x.Value == "A"), Is.EqualTo(1));
            Assert.That(viewModel.Options.Count(x => x.Value == "B"), Is.EqualTo(1));
            Assert.That(viewModel.Options.Count(x => x.Value == "C"), Is.EqualTo(1));
        }

        [Test]
        public void All_Option_Is_Added()
        {
            var viewModel = FilterPanel("A", "B", "C");

            Assert.That(viewModel.Options.Count, Is.EqualTo(4));
            Assert.That(viewModel.Options.Count(x => x.Value == "All"), Is.EqualTo(1));
        }

        [Test]
        public void Duplicates_Are_Not_Added_As_Options()
        {
            var viewModel = FilterPanel("A", "B", "C", "A", "B", "C");

            Assert.That(viewModel.Options.Count, Is.EqualTo(4));
        }

        [Test]
        public void Empties_Are_Not_Added_As_Options()
        {
            var viewModel = FilterPanel("A", "B", "C", "", null);

            Assert.That(viewModel.Options.Count, Is.EqualTo(4));
        }

        [Test]
        public void Option_FilterName_Is_Set_The_Same()
        {
            var viewModel = FilterPanel("A", "B", "C");

            viewModel.Options.Each(o => Assert.That(o.FilterName, Is.EqualTo("Names")));
        }

        [Test]
        public void All_Option_Is_Selected()
        {
            var viewModel = FilterPanel("A", "B", "C");

            Assert.That(viewModel.Options.Any(o => o.Value == "All" && o.Selected == true));
            Assert.That(!viewModel.Options.Any(o => o.Value != "All" && o.Selected == true));
        }

        [Test]
        public void First_Selected_Option_Is_Selected()
        {
            var viewModel = FilterPanel("A", "B", "C");

            SelectOption(viewModel, "B");

            Assert.That(viewModel.Selected, Is.EqualTo("B"));
        }

        private static void SelectOption(FilterGroupViewModel<MyClass> viewModel, string value)
        {
            SelecteNone(viewModel);
            viewModel.Options.First(o => o.Value == value).Selected = true;
        }

        [Test]
        public void When_None_Are_Selected_All_Is_Default()
        {
            var viewModel = FilterPanel("A", "B", "C");

            SelecteNone(viewModel);

            Assert.That(viewModel.Selected, Is.EqualTo("All"));
        }

        private static void SelecteNone(FilterGroupViewModel<MyClass> viewModel)
        {
            viewModel.Options.Each(o => o.Selected = false);
        }

        [Test]
        public void When_Selected_Changes_Filter_And_Selected_Properties_Change()
        {
            string properties = "";
            var viewModel = FilterPanel("A", "B", "C");
            viewModel.PropertyChanged += (s, e) => properties += e.PropertyName;

            viewModel.Options.First().Selected = false;

            Assert.That(properties, Is.EqualTo("FilterSelected"));
        }

        [Test]
        public void Filter_Items_Based_On_Selected_Item()
        {
            var viewModel = FilterPanel("A", "B", "C");

            SelectOption(viewModel, "B");
            var filter = viewModel.Filter;

            Assert.That(filter(new MyClass { Name = "A" }), Is.False);
            Assert.That(filter(new MyClass { Name = "B" }), Is.True);
            Assert.That(filter(new MyClass { Name = "C" }), Is.False);
        }

        [Test]
        public void Filter_Items_When_All_Is_Selected()
        {
            var viewModel = FilterPanel("A", "B", "C");

            SelectOption(viewModel, "All");
            var filter = viewModel.Filter;

            Assert.That(filter(new MyClass { Name = "A" }), Is.True);
            Assert.That(filter(new MyClass { Name = "B" }), Is.True);
            Assert.That(filter(new MyClass { Name = "C" }), Is.True);
        }
    }
}
