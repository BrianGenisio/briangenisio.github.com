﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Helpers;
using Moq;
using CodeMashSessions.Service;
using System.Collections.Generic;
using CodeMashSessions.Model;
using Microsoft.Practices.Composite.Events;

namespace UnitTests.ViewModels
{
    [TestFixture]
    public abstract class ViewModelTests<T> where T : ViewModel
    {
        protected Mock<ICodeMashService> MockService;
        protected Action<IEnumerable<Session>> SessionsCallback;
        protected Action<IEnumerable<UnSession>> UnSessionsCallback;
        private Mock<IEventAggregator> MockAggregator;

        protected T ViewModel;

        [SetUp]
        public void SetUp()
        {
            MockService = new Mock<ICodeMashService>();
            MockService.Setup(s => s.GetSessions(It.IsAny<Action<IEnumerable<Session>>>()))
                .Callback((Action<IEnumerable<Session>> action) => SessionsCallback = action);
            MockService.Setup(s => s.GetUnsessions(It.IsAny<Action<IEnumerable<UnSession>>>()))
                .Callback((Action<IEnumerable<UnSession>> action) => UnSessionsCallback = action);

            MockAggregator = new Mock<IEventAggregator>();
            ConfigureEventAggregator(MockAggregator);

            ViewModel = CreateViewModel(MockService, MockAggregator);
        }

        protected abstract void ConfigureEventAggregator(Mock<IEventAggregator> mockAggregator);
        protected abstract T CreateViewModel(Mock<ICodeMashService> mockService, Mock<IEventAggregator> mockAggregator);
    }
}
