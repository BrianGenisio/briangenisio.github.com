﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.ViewModels;
using Moq;
using Microsoft.Practices.Composite.Events;
using CodeMashSessions.Service;
using System.Collections.Generic;
using CodeMashSessions.Model;
using NUnit.Framework.SyntaxHelpers;
using CodeMashSessions.Helpers;

namespace UnitTests.ViewModels
{
    [TestFixture]
    public class ScheduleViewModelTests : ViewModelTests<ScheduleViewModel>
    {
        private Mock<IResourceDictionary> _resourceDictionary;

        protected override void ConfigureEventAggregator(Mock<IEventAggregator> mockAggregator)
        {
        }

        protected override ScheduleViewModel CreateViewModel(Mock<ICodeMashService> mockService, Mock<IEventAggregator> mockAggregator)
        {
            _resourceDictionary = new Mock<IResourceDictionary>();
            return new ScheduleViewModel(mockService.Object, _resourceDictionary.Object);
        }

        [Test]
        public void GetSessions_And_UnSessions_Is_Requested_On_Startup()
        {
            MockService.Verify(s => s.GetSessions(It.IsAny<Action<IEnumerable<Session>>>()));
            MockService.Verify(s => s.GetUnsessions(It.IsAny<Action<IEnumerable<UnSession>>>()));
        }

        [Test]
        public void Sessions_Received_Get_Translated_Into_Appointments()
        {
            var session = new Session
            {
                Start = DateTime.Parse("1/2/2010 8:00 AM"),
                Title = "Foo",
                Abstract = "This is foo tape",
                Room = "My Room"
            };
            SessionsCallback(new[] { session });

            Assert.That(ViewModel.Appointments.Count, Is.EqualTo(1));
            Assert.That(Appointments().First().Start, Is.EqualTo(DateTime.Parse("1/2/2010 8:00 AM")));
            Assert.That(Appointments().First().End, Is.EqualTo(DateTime.Parse("1/2/2010 9:00 AM")));
            Assert.That(Appointments().First().Subject, Is.EqualTo("Foo"));
            Assert.That(Appointments().First().Session, Is.EqualTo(session));
            Assert.That(Appointments().First().Body, Is.EqualTo("This is foo tape"));
            Assert.That(Appointments().First().Room, Is.EqualTo("My Room"));
        }

        private IEnumerable<ScheduleViewModel.CodemashAppointment> Appointments()
        {
            return ViewModel.Appointments.Cast<ScheduleViewModel.CodemashAppointment>();
        }

        [Test]
        public void Empty_Title_Yields_TBD_In_Appointment()
        {
            SessionsCallback(new[] { new Session() });

            Assert.That(Appointments().First().Subject, Is.EqualTo("TBD"));
        }

        [Test]
        public void UnSessions_Received_Get_Translated_Into_APpointments()
        {
            var unSession = new UnSession
            {
                Start = DateTime.Parse("1/3/2010 9:00 AM"),
                End = DateTime.Parse("1/3/2010 12:00 PM"),
                Title = "MyFoo"
            };

            UnSessionsCallback(new[] { unSession });

            Assert.That(Appointments().Count(), Is.EqualTo(1));
            Assert.That(Appointments().Last().Start, Is.EqualTo(DateTime.Parse("1/3/2010 9:00 AM")));
            Assert.That(Appointments().Last().End, Is.EqualTo(DateTime.Parse("1/3/2010 12:00 PM")));
            Assert.That(Appointments().Last().Subject, Is.EqualTo("MyFoo"));
        }

        [Test]
        public void UnSessions_Get_Put_In_All_Rooms()
        {
            var rooms = new[] { "My Room", "Your Room" };
            var unSession = new UnSession { Title = "MyFoo" };
            
            UnSessionsCallback(new[] { unSession }); 
            SessionsCallback(rooms.Select(room => new Session { Room = room }));

            Assert.That(Appointments().Last().Resources.Count, Is.EqualTo(2));
            Assert.That(Appointments().Last().Resources[0].ResourceName, Is.EqualTo("My Room"));
            Assert.That(Appointments().Last().Resources[1].ResourceName, Is.EqualTo("Your Room"));
        }

    }
}
