﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using System.Collections.Generic;
using CodeMashSessions.Service;
using Moq;
using CodeMashSessions.Helpers;
using CodeMashSessions.Model;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Service
{
    [TestFixture]
    public class CodeMashServiceTests
    {
        private Dictionary<string, string> _speakerImages;
        private List<Speaker> _speakers;
        private List<Session> _sessions;
        private List<UnSession> _unsessions;

        private Mock<IWebReceiver> _mockReceiver;
        private CodeMashService _service;

        [SetUp]
        public void SetUp()
        {
            _speakerImages = new Dictionary<string, string>();
            _speakers = new List<Speaker>();
            _sessions = new List<Session>();
            _unsessions = new List<UnSession>();

            _mockReceiver = new Mock<IWebReceiver>();
            _mockReceiver.Setup(r => r.GetString(It.IsAny<Uri>(), It.IsAny<Action<string>>()))
                .Callback((Uri uri, Action<string> action) =>
                    {
                        switch (uri.OriginalString)
                        {
                            case "SpeakerImages.xml":
                                action(_speakerImages.Serialize().AsString());
                                break;

                            case "UnSessions.xml":
                                action(_unsessions.Serialize().AsString());
                                break;

                            case "http://www.codemash.org/rest/speakers":
                                action(ToXml(_speakers));
                                break;

                            case "http://www.codemash.org/rest/sessions":
                                action(ToXml(_sessions));
                                break;
                        }
                    });

            _service = new CodeMashService(_mockReceiver.Object);
        }

        private string ToXml(IEnumerable<Speaker> speakers)
        {
            return
                "<Speakers>".AsSet()
                .Union(speakers.Select(ToXml))
                .Append("</Speakers>")
                .Join(" ");
        }

        private string ToXml(Speaker speaker)
        {
            return 
                "<Speaker>".AsSet()
                .Append(Element("SpeakerURI", speaker.SpeakerURI))
                .Append(Element("Name", speaker.Name))
                .Append(Element("Biography", speaker.Biography))
                .Append(Element("Sessions", ToXml("SessionURI", speaker.Sessions)))
                .Append(Element("TwitterHandle", speaker.TwitterHandle))
                .Append(Element("BlogURL", speaker.Blog.ToString()))
                .Append("</Speaker>")
                .Join(" ");
        }

        private string ToXml(IEnumerable<Session> sessions)
        {
            return
                "<Sessions>".AsSet()
                .Union(sessions.Select(ToXml))
                .Append("</Sessions>")
                .Join(" ");
        }

        private string ToXml(Session session)
        {
            return
                "<Session>".AsSet()
                .Append(Element("URI", session.SessionURI.ToString()))
                .Append(Element("Title", session.Title))
                .Append(Element("Abstract", session.Abstract))
                .Append(Element("Start", session.Start.ToString()))
                .Append(Element("Room", session.Room))
                .Append(Element("Difficulty", session.Difficulty))
                .Append(Element("SpeakerName", session.Speaker.Name))
                .Append(Element("Technology", session.Technology))
                .Append(Element("Track", session.Track))
                .Append(Element("SpeakerURI", session.Speaker.SpeakerURI.ToString()))
                .Append("</Session>")
                .Join(" ");
        }

        private string ToXml(string nodeName, IEnumerable<Uri> uris)
        {
            uris = uris ?? new List<Uri>();

            return
                nodeName.AsSet()
                .Union(uris.Select(uri => uri.ToString()))
                .Append(nodeName)
                .Join(" ");
        }

        private string Element(string name, string value)
        {
            return string.Format("<{0}>{1}</{0}>", name, value);
        }

        [Test]
        public void GetSessions_Merges_Images_Speakers_And_Sessions()
        {
            _speakerImages.Add("http://www.codemash.org/session", "Image Foo");
            _speakers.Add(new Speaker { Name = "Mr. Foo", SpeakerURI = "http://www.codemash.org/session", Biography = "I am a foo", Blog = new Uri("http://foo.com"), TwitterHandle = "MrFoo" });
            _sessions.Add(new Session { Abstract = "Be an evil foo", Difficulty = "Hard", Room = "My Room", SessionURI = new Uri("/session", UriKind.Relative), Speaker = _speakers[0], Start = DateTime.Parse("1/2/2010 8:00 AM"), Technology = ".Net", Title = "Woo Foo", Track = "Do it like foo" });

            var retrievedSessions = new List<Session>();
            _service.GetSessions(retrievedSessions.AddRange);

            Assert.That(retrievedSessions.Count, Is.EqualTo(1));
            Assert.That(retrievedSessions.First().Abstract, Is.EqualTo("Be an evil foo"));
            Assert.That(retrievedSessions.First().Difficulty, Is.EqualTo("Hard"));
            Assert.That(retrievedSessions.First().Room, Is.EqualTo("My Room"));
            Assert.That(retrievedSessions.First().SessionURI.ToString(), Is.EqualTo("http://www.codemash.org/session"));
            Assert.That(retrievedSessions.First().Start, Is.EqualTo(DateTime.Parse("1/2/2010 8:00 AM")));
            Assert.That(retrievedSessions.First().Technology, Is.EqualTo(".Net"));
            Assert.That(retrievedSessions.First().Title, Is.EqualTo("Woo Foo"));
            Assert.That(retrievedSessions.First().Track, Is.EqualTo("Do it like foo"));

            Assert.That(retrievedSessions.First().Speaker.Name, Is.EqualTo("Mr. Foo"));
            Assert.That(retrievedSessions.First().Speaker.SpeakerURI, Is.EqualTo("http://www.codemash.org/session"));
            Assert.That(retrievedSessions.First().Speaker.Biography, Is.EqualTo("I am a foo"));
            Assert.That(retrievedSessions.First().Speaker.Blog.ToString(), Is.EqualTo("http://foo.com/"));
            Assert.That(retrievedSessions.First().Speaker.TwitterHandle, Is.EqualTo("MrFoo"));
            Assert.That(retrievedSessions.First().Speaker.PhotoURL, Is.EqualTo("Image Foo"));
        }

        [Test]
        public void GetUnsessions_Gets_From_Searialized_Form()
        {
            _unsessions.Add(new UnSession { Start = DateTime.Parse("1/2/2010 8:00 AM"), End = DateTime.Parse("1/2/2010 11:00 AM"), Title = "UnSession eXtreme" });

            var retrievedUnSessions = new List<UnSession>();
            _service.GetUnsessions(retrievedUnSessions.AddRange);

            Assert.That(retrievedUnSessions.Count, Is.EqualTo(1));
            Assert.That(retrievedUnSessions.First().Start, Is.EqualTo(DateTime.Parse("1/2/2010 8:00 AM")));
            Assert.That(retrievedUnSessions.First().End, Is.EqualTo(DateTime.Parse("1/2/2010 11:00 AM")));
            Assert.That(retrievedUnSessions.First().Title, Is.EqualTo("UnSession eXtreme"));
        }

    }
}
