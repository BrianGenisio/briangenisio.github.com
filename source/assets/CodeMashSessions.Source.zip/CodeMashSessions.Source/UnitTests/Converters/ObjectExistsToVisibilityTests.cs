﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Views.Converters;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Converters
{
    [TestFixture]
    public class ObjectExistsToVisibilityTests
    {
        [Test]
        public void Null_Value_Is_Collapsed()
        {
            var result = new ObjectExistsToVisibility().Convert(null, null, null, null);

            Assert.That(result, Is.EqualTo(Visibility.Collapsed));
        }

        [Test]
        public void Null_Value_Reversed_Is_Visible()
        {
            var result = new ObjectExistsToVisibility().Convert(null, null, "reverse", null);

            Assert.That(result, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void Real_Value_Is_Visible()
        {
            var result = new ObjectExistsToVisibility().Convert("", null, null, null);

            Assert.That(result, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void Real_Value_Reversed_Is_Collapsed()
        {
            var result = new ObjectExistsToVisibility().Convert("", null, "reverse", null);

            Assert.That(result, Is.EqualTo(Visibility.Collapsed));
        }
    }
}
