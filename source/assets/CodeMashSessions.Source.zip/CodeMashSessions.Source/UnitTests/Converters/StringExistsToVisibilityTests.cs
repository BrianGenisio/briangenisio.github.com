﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Views.Converters;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Converters
{
    [TestFixture]
    public class StringExistsToVisibilityTests
    {
        [Test]
        public void Null_Value_Is_Collapsed()
        {
            var result = new StringExistsToVisibility().Convert(null, null, null, null);

            Assert.That(result, Is.EqualTo(Visibility.Collapsed));
        }

        [Test]
        public void Null_Value_Reversed_Is_Visible()
        {
            var result = new StringExistsToVisibility().Convert(null, null, "reverse", null);

            Assert.That(result, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void EmptyString_Value_Is_Collapsed()
        {
            var result = new StringExistsToVisibility().Convert("", null, null, null);

            Assert.That(result, Is.EqualTo(Visibility.Collapsed));
        }

        [Test]
        public void EmptyString_Reversed_Is_Visible()
        {
            var result = new StringExistsToVisibility().Convert("", null, "reverse", null);

            Assert.That(result, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void String_Value_Is_Visible()
        {
            var result = new StringExistsToVisibility().Convert("foo", null, null, null);

            Assert.That(result, Is.EqualTo(Visibility.Visible));
        }

        [Test]
        public void String_Reversed_Is_Collapsed()
        {
            var result = new StringExistsToVisibility().Convert("foo", null, "reverse", null);

            Assert.That(result, Is.EqualTo(Visibility.Collapsed));
        }
    }
}
