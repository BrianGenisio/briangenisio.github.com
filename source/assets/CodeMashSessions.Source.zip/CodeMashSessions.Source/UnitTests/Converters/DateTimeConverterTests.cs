﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Views.Converters;
using System.Globalization;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Converters
{
    [TestFixture]
    public class DateTimeConverterTests
    {
        [Test]
        public void Convert_With_No_Format_Uses_Default()
        {
            var date = DateTime.Parse("11/12/13 1:23:45 PM");

            var result = new DateTimeConverter().Convert(date, typeof(string), null, CultureInfo.CurrentCulture);

            Assert.That(result, Is.EqualTo("11/12/2013 1:23:45 PM"));
        }

        [Test]
        public void Convert_With_Format_Formats_Date()
        {
            var date = DateTime.Parse("11/12/13 1:23:45 PM");

            var result = new DateTimeConverter().Convert(date, typeof(string), "MM mm tttt", CultureInfo.CurrentCulture);

            Assert.That(result, Is.EqualTo("11 23 PM"));
        }
    }
}
