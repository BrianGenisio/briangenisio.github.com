﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Helpers;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Helpers
{
    [TestFixture]
    public class PropertyNotifierTests
    {
        public class MyClass : PropertyNotifier
        {
            private string _foo;
            public string Foo
            {
                get { return _foo; }
                set 
                {
                    _foo = value;
                    RaisePropertyChanged("Foo");
                }
            }
        }

        [Test]
        public void Setting_Value_Raises_PropertyChangedEvent()
        {
            var tester = new MyClass();
            string property = "";
            tester.PropertyChanged += (s, e) => property += e.PropertyName;

            tester.Foo = "Bar";

            Assert.That(property, Is.EqualTo("Foo"));
        }
    }
}
