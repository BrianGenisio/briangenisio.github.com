﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using NUnit.Framework;
using CodeMashSessions.Helpers;
using NUnit.Framework.SyntaxHelpers;

namespace UnitTests.Helpers
{
    [TestFixture]
    public class LazyTests
    {
        public class MyClass
        {
            public string Foo { get; set; }
        }

        [Test]
        public void HasValue_False_When_Not_Hydrated()
        {
            var lazy = new Lazy<MyClass>();

            Assert.That(lazy.HasValue, Is.False);
        }

        [Test]
        public void HasValue_True_When_Hydrated()
        {
            var lazy = new Lazy<MyClass>();

            var hydrated = lazy.Value;

            Assert.That(hydrated, Is.Not.Null);
            Assert.That(lazy.HasValue);
        }

        [Test]
        public void Value_Is_Only_Created_Once()
        {
            var lazy = new Lazy<MyClass>();

            lazy.Value.Foo = "Bar";

            Assert.That(lazy.Value.Foo, Is.EqualTo("Bar"));
        }
    }
}
