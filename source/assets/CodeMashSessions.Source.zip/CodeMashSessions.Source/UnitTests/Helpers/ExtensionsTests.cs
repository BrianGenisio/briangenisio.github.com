﻿using System.Linq;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using NUnit.Framework.SyntaxHelpers;
using NUnit.Framework;
using CodeMashSessions.Helpers;
using System;

namespace UnitTests.Helpers
{
    [TestFixture]
    public class ExtensionsTests
    {
        [Test]
        public void AddRange_To_Collection()
        {
            var collection = new ObservableCollection<int>();
            collection.AddRange(new[] { 1, 2, 3 });

            Assert.That(collection.ToArray(), Is.EqualTo(new[] { 1, 2, 3 }));
        }

        [Test]
        public void RemoveRange_From_Collection()
        {
            var collection = new List<int>(new[] {1, 2, 3});

            collection.RemoveRange(new[] { 2 });

            Assert.That(collection.ToArray(), Is.EqualTo(new[] { 1, 3 }));
        }

        [Test]
        public void Each_Enumerable_Calls_Action()
        {
            int sum = 0;
            var colleciton = new List<int>(new[] { 1, 2, 3 });

            colleciton.Each(x => sum += x);

            Assert.That(sum, Is.EqualTo(6));
        }

        [Test]
        public void Append_To_Set()
        {
            var collection = new List<int>(new[] { 1, 2 }).AsEnumerable();

            collection = collection.Append(3);

            Assert.That(collection.ToArray(), Is.EqualTo(new[] { 1, 2, 3 }));
        }

        [Test]
        public void Prepend_To_Set()
        {
            var collection = new List<int>(new[] { 1, 2 }).AsEnumerable();

            collection = collection.Prepend(3);

            Assert.That(collection.ToArray(), Is.EqualTo(new[] { 3, 1, 2 }));
        }

        public event EventHandler MyHandler;
        [Test]
        public void Raise_EventHandler_Fires_Event()
        {
            bool handlerWasCalled = false;
            MyHandler += (s, e) => handlerWasCalled = true;

            MyHandler.Raise(this);

            Assert.That(handlerWasCalled);
        }

        [Test]
        public void Serialize_And_Deserialize()
        {
            var collection = new List<int>(new[] { 1, 2 }).AsEnumerable();
            
            var serialized = collection.Serialize().AsString();
            var deserialized = serialized.Deserialize<List<int>>();

            Assert.That(collection, Is.EqualTo(deserialized));
        }

        [Test]
        public void Object_As_Set()
        {
            var singleSet = 22.AsSet().ToList();

            Assert.That(singleSet.Count, Is.EqualTo(1));
            Assert.That(singleSet[0], Is.EqualTo(22));
        }

        [Test]
        public void String_Join()
        {
            var strings = new List<string> { "a", "b", "c" };

            Assert.That(strings.Join(" "), Is.EqualTo("a b c"));
        }
    }
}
