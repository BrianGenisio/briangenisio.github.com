﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using eRecipe.Shared;

namespace Tests
{
    [TestClass]
    public class ViewModelTests
    {
        private TestViewModel _viewModel;

        private class TestViewModel : ViewModel
        {
            public void Fire(string name) { OnPropertyChanged(name); }
            public void SetupAction(string name, Action action) { AddAction(name, action); }
        }

        [TestInitialize]
        public void Setup()
        {
            _viewModel = new TestViewModel();
        }

        [TestMethod]
        public void OnPropertyChanged_Fires_Change()
        {
            string propertyChanged = string.Empty;
            _viewModel.PropertyChanged += (s, e) => propertyChanged += e.PropertyName;

            _viewModel.Fire("FOO");

            Assert.AreEqual("FOO", propertyChanged);
        }

        [TestMethod]
        public void OnPropertyChanged_Fires_Action()
        {
            bool actionFired = false;
            _viewModel.SetupAction("Foo", () => actionFired = true);

            _viewModel.Fire("Foo");

            Assert.IsTrue(actionFired);
        }

        [TestMethod]
        public void OnPropertyChanged_Does_Not_Fire_Action_If_Wrong_Name()
        {
            bool actionFired = false;
            _viewModel.SetupAction("Foo", () => actionFired = true);

            _viewModel.Fire("Foo2");

            Assert.IsFalse(actionFired);
        }
    }
}