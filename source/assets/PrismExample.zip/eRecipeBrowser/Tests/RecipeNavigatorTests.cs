﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Silverlight.Testing;
using eRecipeNavigator;
using Moq;
using eRecipe.Shared;
using Microsoft.Practices.Composite.Events;

namespace Tests
{
    [TestClass]
    public class RecipeNavigatorTests : SilverlightTest
    {
        private RecipeNavigator _navigator;
        private RecipieNavigatorViewModel _viewModel;
        private Mock<IRecipeService> _mockService;
        private Mock<IEventAggregator> _mockEventAggregator;

        [TestInitialize]
        public void SetUp()
        {
            _mockService = new Mock<IRecipeService>();
            _mockEventAggregator = new Mock<IEventAggregator>();
            _viewModel = new RecipieNavigatorViewModel(_mockService.Object, _mockEventAggregator.Object);
            _navigator = new RecipeNavigator(_viewModel);

            TestPanel.Children.Add(_navigator);
        }

        [TestMethod]
        public void Simple()
        {
        }
    }
}
