﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using eRecipeNavigator;
using eRecipe.Shared;
using Moq;
using Microsoft.Practices.Composite.Events;
using System.Collections.Generic;

namespace Tests
{
    [TestClass]
    public class NavigatorViewModelTests
    {
        private RecipieNavigatorViewModel _viewModel;
        private Mock<IRecipeService> _mockService;
        private Mock<IEventAggregator> _mockEventAggregator;

        [TestInitialize]
        public void SetUp()
        {
            _mockService = new Mock<IRecipeService>();
            _mockEventAggregator = new Mock<IEventAggregator>();
            
            _viewModel = new RecipieNavigatorViewModel(_mockService.Object, _mockEventAggregator.Object);
        }

        [TestMethod]
        public void Search_Causes_Service_To_Search()
        {
            _viewModel.SearchText = "Pumpkin";

            _viewModel.Search.Execute(null);

            _mockService.Verify(service => service.Search("Pumpkin", 1, It.IsAny<Action<int, int, IEnumerable<RecipeMetaData>>>()));
        }

        [TestMethod]
        public void Selection_Changed_Causes_ShowRecipe_To_Fire()
        {
            var mockEvent = new Mock<ShowRecipeEvent>();
            _mockEventAggregator.Setup(ea => ea.GetEvent<ShowRecipeEvent>()).Returns(mockEvent.Object);

            var metaData = new RecipeMetaData { ID = 55, Title = "My Food" };
            _viewModel.Selected = metaData;

            mockEvent.Verify(e => e.Publish(metaData));
        }

        private void SetupResults(string queryString, params string[] names)
        {
            var recipes = names.Select(name => new RecipeMetaData { Title = name });
            _mockService.Setup(service => service.Search(queryString, 1, It.IsAny<Action<int, int, IEnumerable<RecipeMetaData>>>()))
                .Callback<string, int, Action<int, int, IEnumerable<RecipeMetaData>>>((query, page, action) => action(names.Length, 20, recipes));
        }

        [TestMethod]
        public void Search_Results_Get_Set_As_Results()
        {
            SetupResults("Foo", "Recipe1", "Recipe2");

            _viewModel.SearchText = "Foo";
            _viewModel.Search.Execute(null);

            Assert.AreEqual(2, _viewModel.SearchResults.Count);
            Assert.AreEqual("Recipe1", _viewModel.SearchResults[0].Title);
            Assert.AreEqual("Recipe2", _viewModel.SearchResults[1].Title);
        }

        [TestMethod]
        public void Search_Results_Clears_Existing_Results()
        {
            SetupResults("Foo");
            
            _viewModel.SearchResults.Add(new RecipeMetaData { Title = "First" });
            _viewModel.SearchResults.Add(new RecipeMetaData { Title = "First" });
            _viewModel.SearchText = "Foo";
            _viewModel.Search.Execute(null);

            Assert.AreEqual(0, _viewModel.SearchResults.Count);
        }

        [TestMethod]
        public void Searching_Causes_Loading_Panel_To_Show()
        {
            Assert.AreEqual(Visibility.Collapsed, _viewModel.ShowProgress);

            _viewModel.Search.Execute(null);

            Assert.AreEqual(Visibility.Visible, _viewModel.ShowProgress);
        }

        [TestMethod]
        public void Search_Results_Hides_Loading_Panel()
        {
            SetupResults("Foo", "Recipe1", "Recipe2");

            _viewModel.SearchText = "Foo";
            _viewModel.Search.Execute(null);

            Assert.AreEqual(Visibility.Collapsed, _viewModel.ShowProgress);
        }
    }
}
