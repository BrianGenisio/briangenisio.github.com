﻿using System;
using System.Net;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using eRecipeViewer;
using eRecipe.Shared;
using Moq;
using Microsoft.Practices.Composite.Events;

namespace Tests
{
    [TestClass]
    public class RecipeViewerViewModelTests
    {
        private RecipeViewerViewModel _viewModel;
        private Mock<IRecipeService> _mockService;
        private Mock<IEventAggregator> _mockAggregator;

        [TestInitialize]
        public void SetUp()
        {
            _mockService = new Mock<IRecipeService>();
            _mockAggregator = new Mock<IEventAggregator>();

            Setup("TEST", 0);
        }

        private void Setup(string title, int ID)
        {
            _viewModel = new RecipeViewerViewModel(_mockService.Object, _mockAggregator.Object, new RecipeMetaData { ID = ID, Title = title });
        }

        [TestMethod]
        public void Default_Visibility_For_Loading_Panel_Is_Shown()
        {
            Assert.AreEqual(Visibility.Visible, _viewModel.ShowLoadingPanel);
        }

        [TestMethod]
        public void Construction_Causes_Request_For_Recipe()
        {
            Setup("TEST", 55);

            _mockService.Verify(service => service.GetRecipe(55, It.IsAny<Action<Recipe>>()));
        }

        private void SetupRecipe(Recipe recipe)
        {
            _mockService.Setup(service => service.GetRecipe(It.IsAny<int>(), It.IsAny<Action<Recipe>>()))
               .Callback((int id, Action<Recipe> action) => action(recipe));
        }

        [TestMethod]
        public void Recipe_Received_Is_Set_As_Recipe()
        {
            SetupRecipe(new Recipe { Title = "FooBar" });
           
            Setup("TEST", 0);

            Assert.AreEqual("FooBar", _viewModel.Recipe.Title);
        }

        [TestMethod]
        public void Recipe_Received_Formats_Ingredients()
        {
            SetupRecipe(new Recipe
            {
                Title = "Foobar",
                Ingredients = new [] 
                { 
                    new Ingredient { Quantity = "0.50", Unit = "Cups"},
                    new Ingredient { Quantity = "0.75", Unit = "Teaspoons"},
                }
            });

            Setup("TEST", 0);

            Assert.AreEqual("1/2", _viewModel.Recipe.Ingredients.ToList()[0].Quantity);
            Assert.AreEqual("3/4", _viewModel.Recipe.Ingredients.ToList()[1].Quantity);

            Assert.AreEqual("c", _viewModel.Recipe.Ingredients.ToList()[0].Unit);
            Assert.AreEqual("tsp", _viewModel.Recipe.Ingredients.ToList()[1].Unit);
        }

        [TestMethod]
        public void Recipe_Recieved_Formats_Servigs()
        {
            SetupRecipe(new Recipe { Title = "FooBar", Servings = 5 });

            Setup("TEST", 0);

            Assert.AreEqual("Serves 5", _viewModel.Servings);
        }

        [TestMethod]
        public void Recipe_Received_Collapses_Loading_Screen()
        {
            SetupRecipe(new Recipe { Title = "FooBar" });

            Setup("TEST", 0);

            Assert.AreEqual(Visibility.Collapsed, _viewModel.ShowLoadingPanel);
        }

        [TestMethod]
        public void ToString_Uses_MetaData_When_Recipe_Is_Not_Loaded_Yet()
        {
            Setup("TEST Foo", 0);

            Assert.AreEqual("TEST Foo", _viewModel.ToString());
        }

        [TestMethod]
        public void ToString_Uses_Recipe_When_Recipe_Is_Loaded()
        {
            SetupRecipe(new Recipe { Title = "FooBar" });

            Setup("TEST", 0);

            Assert.AreEqual("FooBar", _viewModel.ToString());
        }

        [TestMethod]
        public void ID_Comes_From_MetaData()
        {
            Setup("TEST", 99);

            Assert.AreEqual(99, _viewModel.ID);
        }

        [TestMethod]
        public void Pressing_Close_Button_Causes_Event_To_Fire()
        {
            var mockEvent = new Mock<RemoveRecipeEvent>();
            _mockAggregator.Setup(ea => ea.GetEvent<RemoveRecipeEvent>()).Returns(mockEvent.Object);

            _viewModel.Close.Execute(null);

            mockEvent.Verify(e => e.Publish(0));
        }

    }
}
