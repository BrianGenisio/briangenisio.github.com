﻿using System.IO;
using eRecipeBrowser.Web.www.ecuisine.org;

namespace eRecipeBrowser.Web
{
    public class OfflineRecipeService : IRecipe
    {
        public WRecipeResults SearchRecipes(string criteria, int pageNumber)
        {
            string path = "C:\\RecipeData\\" + criteria + ".searchResults";
            if (File.Exists(path))
                return File.OpenRead(path).DeSerialize<WRecipeResults>();

            return new WRecipeResults {Recipes = new[] {new WRecipe {Name = "Not Found"}}};
        }

        public WRecipe GetRecipe(int ID)
        {
            string path = "C:\\RecipeData\\" + ID + ".recipe";
            if (File.Exists(path))
                return File.OpenRead(path).DeSerialize<WRecipe>();

            return new WRecipe {Directions = "Not Found", Ingredients = new WIngredient[0]};
        }
    }
}