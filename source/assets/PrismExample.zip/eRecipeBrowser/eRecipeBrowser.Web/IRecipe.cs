﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using eRecipeBrowser.Web.www.ecuisine.org;

namespace eRecipeBrowser.Web
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRecipe" in both code and config file together.
    [ServiceContract]
    public interface IRecipe
    {
        [OperationContract]
        WRecipeResults SearchRecipes(string criteria, int pageNumber);

        [OperationContract]
        WRecipe GetRecipe(int ID);
    }
}
