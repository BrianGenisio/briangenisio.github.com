﻿using System.IO;
using System.Runtime.Serialization;

namespace eRecipeBrowser.Web
{
    public static class PersistenceExtensions
    {
        public static MemoryStream Serialize<T>(this T value)
        {
            var memStream = new MemoryStream();
            var serializer = new DataContractSerializer(typeof(T));
            serializer.WriteObject(memStream, value);
            memStream.Flush();
            memStream.Position = 0;
            return memStream;
        }

        public static string AsString(this MemoryStream memStream)
        {
            return System.Text.Encoding.ASCII.GetString(memStream.ToArray());
        }

        public static T DeSerialize<T>(this Stream data)
        {
            var serializer = new DataContractSerializer(typeof (T));
            return (T)serializer.ReadObject(data);
        }
    }
}