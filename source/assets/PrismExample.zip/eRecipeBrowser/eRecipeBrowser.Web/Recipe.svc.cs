﻿using System;
using eRecipeBrowser.Web.www.ecuisine.org;

namespace eRecipeBrowser.Web
{
    public class Recipe : IRecipe
    {
        //private readonly IRecipe recipeService = new RecipeServiceRecorder(new eCuisineService());
        //private readonly IRecipe recipeService = new OfflineRecipeService();
        private readonly IRecipe recipeService = new eCuisineService();

        public WRecipeResults SearchRecipes(string criteria, int pageNumber)
        {
            return recipeService.SearchRecipes(criteria, pageNumber);
        }

        public WRecipe GetRecipe(int ID)
        {
            return recipeService.GetRecipe(ID);
        }
    }
}
