﻿using System.IO;
using eRecipeBrowser.Web.www.ecuisine.org;

namespace eRecipeBrowser.Web
{
    internal class RecipeServiceRecorder : IRecipe
    {
        private readonly IRecipe service;

        public RecipeServiceRecorder(IRecipe service)
        {
            this.service = service;
        }

        public WRecipeResults SearchRecipes(string criteria, int pageNumber)
        {
            var result = service.SearchRecipes(criteria, pageNumber);

            using (var writer = new StreamWriter("c:\\recipedata\\" + criteria + ".searchResults"))
                writer.Write(result.Serialize().AsString());

            return result;
        }

        public WRecipe GetRecipe(int ID)
        {
            var result = service.GetRecipe(ID);

            using (var writer = new StreamWriter("c:\\recipedata\\" + ID + ".recipe"))
                writer.Write(result.Serialize().AsString());

            return result;
        }
    }
}