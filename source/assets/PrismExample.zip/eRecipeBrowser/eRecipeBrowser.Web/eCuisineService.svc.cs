﻿using eRecipeBrowser.Web.www.ecuisine.org;

namespace eRecipeBrowser.Web
{
    internal class eCuisineService : IRecipe
    {
        private const int apiKey = 153;
        private const string apiEmail = "BrianGenisio@Gmail.com";

        public WRecipeResults SearchRecipes(string criteria, int pageNumber)
        {
            return new RecipeService().SearchRecipes(criteria, pageNumber, apiKey, apiEmail);
        }

        public WRecipe GetRecipe(int ID)
        {
            return new RecipeService().GetRecipe(ID, apiKey, apiEmail);
        }
    }
}