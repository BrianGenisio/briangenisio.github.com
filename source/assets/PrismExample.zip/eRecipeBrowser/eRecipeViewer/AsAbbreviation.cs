﻿using System.Collections.Generic;

namespace eRecipeViewer
{
    public static class AsAbbreviation
    {
        private static readonly Dictionary<string, string> _lookup = new Dictionary<string, string>
        {
            {"cup", "c"},
            {"cups", "c"},
            {"teaspoon", "tsp"},
            {"teaspoons", "tsp"},
            {"tablespoon", "tbsp"},
            {"tablespoons", "tbsp"}
        };

        public static string Abbreviate(this string value)
        {
            value = value.ToLower();
            if(_lookup.ContainsKey(value))
                return _lookup[value];

            return value;
        }
    }
}
