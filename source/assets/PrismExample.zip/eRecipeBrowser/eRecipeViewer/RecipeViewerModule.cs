﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Regions;
using Microsoft.Practices.Composite.Events;
using eRecipe.Shared;
using Microsoft.Practices.Composite.Presentation.Events;

namespace eRecipeViewer
{
    public class RecipeViewerModule : IModule
    {
        private readonly IRegionManager _regionManager;
        private readonly IEventAggregator _eventAggregator;
        private readonly IRecipeService _service;

        public RecipeViewerModule(IRecipeService service, IRegionManager regionManager, IEventAggregator eventAggregator )
        {
            _service = service;
            _regionManager = regionManager;
            _eventAggregator = eventAggregator;
        }

        public void Initialize()
        {
            _eventAggregator.GetEvent<ShowRecipeEvent>().Subscribe(ShowRecipe, ThreadOption.UIThread, true);
            _eventAggregator.GetEvent<RemoveRecipeEvent>().Subscribe(RemoveRecipe);
        }

        public void ShowRecipe(RecipeMetaData metaData)
        {
            _regionManager.AddToRegion("Recipes", CreateRecipeViewer(metaData), true);
        }

        public void RemoveRecipe(int ID)
        {
            _regionManager.Regions["Recipes"].RemoveWhere(IdIs(ID));
        }
        
        private static Predicate<FrameworkElement> IdIs(int ID)
        {
            return view => 
                {
                    var viewModel = view.DataContext as RecipeViewerViewModel;
                    return viewModel != null && viewModel.ID == ID;
                };
        }

        private RecipeViewer CreateRecipeViewer(RecipeMetaData metaData)
        {
            return new RecipeViewer(new RecipeViewerViewModel(_service, _eventAggregator, metaData));
        }
    }

    public static class RegionExtensions
    {
        public static void RemoveWhere(this IRegion region, Predicate<FrameworkElement> clause)
        {
            var foundView = region.Views
                .Where(view => view is FrameworkElement)
                .FirstOrDefault(view => clause(view as FrameworkElement));

            if (foundView != null)
                region.Remove(foundView);
        }
    }
}
