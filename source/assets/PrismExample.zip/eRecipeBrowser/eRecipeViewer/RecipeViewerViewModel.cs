﻿using eRecipe.Shared;
using Microsoft.Practices.Composite.Presentation.Commands;
using Microsoft.Practices.Composite.Events;
using System.Windows;

namespace eRecipeViewer
{
    public class RecipeViewerViewModel : ViewModel
    {
        private readonly IEventAggregator _eventAggregator;
        private readonly RecipeMetaData _metaData;

        public RecipeViewerViewModel()
        {}

        public RecipeViewerViewModel(IRecipeService service, IEventAggregator aggregator, RecipeMetaData metaData)
        {
            _eventAggregator = aggregator;
            _metaData = metaData;

            Close = new DelegateCommand<object>(param => CloseRecipe());
            ShowLoadingPanel = Visibility.Visible;

            service.GetRecipe(metaData.ID, GetRecipeComplete);
        }

        private void GetRecipeComplete(Recipe recipe)
        {
            Recipe = recipe;
            FormatIngredients();
            Servings = string.Format("Serves {0}", recipe.Servings);
            ShowLoadingPanel = Visibility.Collapsed;
        }

        private void FormatIngredients()
        {
            if (Recipe.Ingredients == null) return;

            foreach (var ingredient in Recipe.Ingredients)
            {
                ingredient.Quantity = ingredient.Quantity.AsFraction();
                ingredient.Unit = ingredient.Unit.Abbreviate();
            }
        }

        public override string ToString()
        {
            return Recipe != null ? Recipe.Title : _metaData.Title;
        }

        public int ID
        {
            get { return _metaData.ID; }
        }

        private string _servings;
        public string Servings
        {
            get { return _servings; }
            set
            {
                _servings = value;
                OnPropertyChanged("Servings");
            }
        }


        private Recipe _recipe;
        public Recipe Recipe
        {
            get { return _recipe; }
            set
            {
                _recipe = value;
                OnPropertyChanged("Recipe");
            }
        }

        private Visibility _showLoadingPanel;
        public Visibility ShowLoadingPanel
        {
            get { return _showLoadingPanel; }
            set
            {
                _showLoadingPanel = value;
                OnPropertyChanged("ShowLoadingPanel");
            }
        }

        public DelegateCommand<object> Close { get; private set; }
        private void CloseRecipe()
        {
            _eventAggregator.GetEvent<RemoveRecipeEvent>().Publish(ID);
        }
    }
}
