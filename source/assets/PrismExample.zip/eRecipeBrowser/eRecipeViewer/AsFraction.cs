﻿using System;
namespace eRecipeViewer
{
    public static class AsFractionFormatter
    {
        public static string AsFraction(this string value)
        {
            if (string.IsNullOrEmpty(value))
                return "";

            var splits = value.Split('.');
            var primary = splits[0];
            var fraction = splits[1];

            if (fraction == "00")
                return primary;

            try
            {
                fraction = TranslateFraction(fraction);
            }
            catch(ArgumentException)
            {
                return value;
            }

            if (primary == "0")
                return fraction;

            return primary + " " + fraction;
        }

        private static string TranslateFraction(string fraction)
        {
            switch (fraction)
            {
                case "13":
                    return "1/8";

                case "25":
                    return "1/4";

                case "33":
                    return "1/3";

                case "50":
                    return "1/2";

                case "66":
                case "67":
                    return "2/3";

                case "75":
                    return "3/4";
            }

            throw new ArgumentException("fraction was unknown");
        }

       
    }
}
