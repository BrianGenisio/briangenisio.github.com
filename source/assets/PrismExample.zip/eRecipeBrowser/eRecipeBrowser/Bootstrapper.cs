﻿using System;
using System.Windows;
using Microsoft.Practices.Composite.UnityExtensions;
using Microsoft.Practices.Composite.Modularity;
using eRecipe.Shared;
using Microsoft.Practices.Composite.Presentation.Regions;

namespace eRecipeBrowser
{
    public class Bootstrapper : UnityBootstrapper
    {
        protected override void ConfigureContainer()
        {
            base.ConfigureContainer();

            Container.RegisterType<IRecipeService, eRecipeService>();
        }

        protected override IModuleCatalog GetModuleCatalog()
        {
            //var catalog = new ModuleCatalog();
            //catalog.AddModule(typeof(NavigatorModule));
            //catalog.AddModule(typeof(RecipeViewerModule));
            //return catalog;

            return ModuleCatalog.CreateFromXaml(new Uri("/eRecipeBrowser;component/modules.xaml", UriKind.Relative));
        }

        protected override DependencyObject CreateShell()
        {
            return Application.Current.RootVisual = new Shell();
        }
    }
}
