﻿using System;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using eRecipe.Shared;
using eRecipeBrowser.Web.RecipeService;

namespace eRecipeBrowser
{
    public class eRecipeService : IRecipeService
    {
        public void Search(string criteria, int pageNumber, Action<int, int, System.Collections.Generic.IEnumerable<RecipeMetaData>> whenComplete)
        {
            var service = new RecipeClient();
            service.SearchRecipesCompleted += (sender, args) => SearchComplete(args, whenComplete);
            service.SearchRecipesAsync(criteria, pageNumber);
        }

        private void SearchComplete(SearchRecipesCompletedEventArgs args, Action<int, int, System.Collections.Generic.IEnumerable<RecipeMetaData>> whenComplete)
        {
            var pageSize = args.Result.pageSizeField;
            var total = args.Result.totalCountField;
            var recipes = from recipe in args.Result.recipesField
                          select new RecipeMetaData
                          {
                            Title = recipe.nameField,
                            ID = recipe.idField
                          };

            whenComplete(pageSize, total, recipes);
        }

        public void GetRecipe(int id, Action<Recipe> whenComplete)
        {
            var service = new RecipeClient();
            service.GetRecipeCompleted += (sender, args) => GetComplete(args, whenComplete);
            service.GetRecipeAsync(id);
        }

        private void GetComplete(GetRecipeCompletedEventArgs args, Action<Recipe> whenComplete)
        {
            var ingredients = from ingredient in args.Result.ingredientsField
                              select new Ingredient {
                                  Name = ingredient.nameField,
                                  Quantity = ingredient.quantityField,
                                  Unit = ingredient.measurementField
                              };

            var recipe = new Recipe {
                Title = args.Result.nameField,
                Directions = args.Result.directionsField,
                Servings = args.Result.servingsField,
                Ingredients = ingredients.ToArray()
            };

            whenComplete(recipe);
        }
    }
}
