﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace eRecipe.Shared
{
    public class RecipeMetaData
    {
        public string Title { get; set; }
        public int ID { get; set; }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public string Quantity { get; set; }
        public string Unit { get; set; }
    }

    public class Recipe
    {
        public string Title { get; set; }
        public int Servings { get; set; }
        public string Directions { get; set; }
        public IEnumerable<Ingredient> Ingredients { get; set; }
    }

    public class IngredientList : List<Ingredient>
    {}

    public interface IRecipeService
    {
        void Search(string criteria, int pageNumber, Action<int, int, IEnumerable<RecipeMetaData>> whenComplete);
        void GetRecipe(int id, Action<Recipe> whenComplete);
    }
}
