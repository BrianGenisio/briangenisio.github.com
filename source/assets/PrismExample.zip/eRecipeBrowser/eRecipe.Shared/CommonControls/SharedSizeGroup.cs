﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace eRecipe.Shared
{
	/// <summary> Class for synchronizing the dimensions of SharedSizePanel controls. </summary>
	public class SharedSizeGroup
	{
		/// <summary> Internal set of panels which are subscribed to this groups, with their last measures sizes. </summary>
		private Dictionary<SharedSizePanel, Size> FPanels = new Dictionary<SharedSizePanel, Size>();

		/// <summary> Registers the given panel with this group. </summary>
		/// <remarks> Nothing is done if the panel is already registered.  If newly registered, this and all other panels in the group will be re-measured. </remarks>
		public void RegisterPanel(SharedSizePanel AElement)
		{
			if (!FPanels.ContainsKey(AElement))
			{
				FPanels.Add(AElement, new Size(0, 0));

				InvalidateAllMeasure();
			}
		}

		/// <summary> Unregisters the given panel from this group. </summary>
		/// <remarks> All panels in the group will be re-measured. </remarks>
		public void UnregisterPanel(SharedSizePanel APanel)
		{
			// Invalidate all measurements (first to ensure that the unregistered panel is included)
			InvalidateAllMeasure();
			
			// Removes the panel if it is registered
			FPanels.Remove(APanel);
		}

		/// <summary> Used internally to invalidate all registered panels. </summary>
		private void InvalidateAllMeasure()
		{
			foreach (KeyValuePair<SharedSizePanel, Size> LEntry in FPanels)
				LEntry.Key.InvalidateMeasure();
		}

		/// <summary> Internally cached measured size. </summary>
		private Size FSize = new Size(0, 0);

		/// <summary> Measures the current group in reaction to a measurement of the given panel. </summary>
		/// <remarks> This method is optimized to only re-measure the group sizes if the given 
		/// change appears possible to change the measurement. </remarks>
		/// <param name="APanel"> The panel that is being measured. </param>
		/// <param name="AMeasured"> The (new) content size of the given panel. </param>
		/// <returns> The size of the group. </returns>
		internal Size Measure(SharedSizePanel APanel, Size AMeasured)
		{
			System.Diagnostics.Debug.Assert(FPanels.ContainsKey(APanel), "Attempt to measure by unregistered panel.");
			Size LOldSize = FPanels[APanel];

			if 
			(
				LOldSize != AMeasured 
					&& 
					(
						APanel.WidthGroup != this 
							|| LOldSize.Width >= FSize.Width 
							|| APanel.HeightGroup != this 
							|| LOldSize.Height >= FSize.Height
					)
			)
			{
				// Set the measured size for the given panel
				FPanels[APanel] = AMeasured;
				
				// Measure the group
				FSize = new Size(0, 0);
				foreach (KeyValuePair<SharedSizePanel, Size> LEntry in FPanels)
				{
					if ((LEntry.Key.WidthGroup == this) && (LEntry.Value.Width > FSize.Width))
						FSize.Width = LEntry.Value.Width;
					if ((LEntry.Key.HeightGroup == this) && (LEntry.Value.Height > FSize.Height))
						FSize.Height = LEntry.Value.Height;
				}
				
				// Invalidate the measurement of all but the given panel
				foreach (KeyValuePair<SharedSizePanel, Size> LEntry in FPanels)
					if (LEntry.Key != APanel)
						LEntry.Key.InvalidateMeasure();
			}
			return FSize;
		}
	}
}
