﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using eRecipe.Shared;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Practices.Composite.Presentation.Commands;
using System.Collections.ObjectModel;
using Microsoft.Practices.Composite.Events;
using System.Windows;
using Microsoft.Practices.ServiceLocation;

namespace eRecipeNavigator
{
    public class RecipieNavigatorViewModel : ViewModel
    {
        private readonly IRecipeService _service;
        private readonly IEventAggregator _eventAggregator;

        public RecipieNavigatorViewModel(IRecipeService service, IEventAggregator eventAggregator)
        {
            _service = service;
            _eventAggregator = eventAggregator;

            AddAction("Selected", SelectedChanged);

            Search = new DelegateCommand<object>(SearchRecipes);
            SearchResults = new ObservableCollection<RecipeMetaData>();
            ShowProgress = Visibility.Collapsed;
        }

        private void SearchRecipes(object parameter)
        {
            ShowProgress = Visibility.Visible;
            _service.Search(SearchText, 1, SearchComplete);
        }

        private void SearchComplete(int pageNumber, int totalCount, IEnumerable<RecipeMetaData> recipes)
        {
            ShowProgress = Visibility.Collapsed;
            SearchResults.Clear();
            foreach (var recipe in recipes)
                SearchResults.Add(recipe);
        }

        private void SelectedChanged()
        {
            if(Selected != null)
                _eventAggregator.GetEvent<ShowRecipeEvent>().Publish(Selected);
        }

        public string SearchText { get; set; }
        public ICommand Search { get; private set; }
        public ObservableCollection<RecipeMetaData> SearchResults { get; private set; }

        private RecipeMetaData _selected;
        public RecipeMetaData Selected
        {
            get { return _selected; }
            set
            {
                _selected = value;
                OnPropertyChanged("Selected");
            }
        }

        private Visibility _showProgress;
        public Visibility ShowProgress
        {
            get { return _showProgress; }
            set
            {
                _showProgress = value;
                OnPropertyChanged("ShowProgress");
            }
        }
    }
}
